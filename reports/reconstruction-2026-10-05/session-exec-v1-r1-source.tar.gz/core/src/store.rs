//! Shared single-database storage with native and explicitly selected OPFS adapters. Only a trusted host owns Store and HostPolicy.
//! SQLite pages/indices are engine-owned; business payloads are Protobuf + LZ4.
use crate::{
    Error, Result,
    content::CardRecord,
    envelope, identity,
    runtime::RenameRequest,
    transaction::{self, Lookup, Receipt},
};
use rusqlite::{Connection, OptionalExtension, TransactionBehavior, params};
use std::{path::Path, time::Duration};
#[cfg(target_os = "linux")]
mod linux_protected;
mod binding;
#[cfg(not(target_arch = "wasm32"))]
mod changes_metadata;
#[cfg(not(target_arch = "wasm32"))]
pub use changes_metadata::{ChangesBatch, ChangesBudget, ChangesStart, ChangesStoreBinding, ChangesWindow};
mod agent_ledger;
pub use agent_ledger::MAX_RECORDS as MAX_AGENT_LEDGER_RECORDS;
mod channel_journal;
pub use channel_journal::{ChannelCheckpoint, ChannelAckReceipt, ChannelCommit, MAX_CHANNEL_RECEIPTS};
mod card_snapshot;
pub use card_snapshot::{CardPage, CardReadSnapshot, Census, FrozenCard, ReadPoint};
mod blobs;
mod evidence;
mod evidence_chunks;
mod io_intent;
mod io_history;
mod open_verification;
pub use io_intent::IoIntentReservation;
mod io_evidence;
mod outbound_authority;
pub use outbound_authority::OutboundAuthorityPage;
mod tls_identity;
pub use tls_identity::{MAX_RECORDS as MAX_TLS_IDENTITIES, TlsIdentityPage};
mod service_authority;
pub use service_authority::ServiceAuthorityPage;
mod service_authority_lock;
mod service_config;
pub use service_config::ServiceConfigPage;
mod file_content;
mod file_content_receipt;
mod file_mutation;
mod file_mutation_discovery;
pub use file_mutation_discovery::{
    FileMutationPlanCheckpoint, FileMutationPlanCursor, FileMutationPlanPage,
    MAX_FILE_MUTATION_PLAN_BYTES, MAX_FILE_MUTATION_PLAN_MATERIAL_BYTES,
    MAX_FILE_MUTATION_PLAN_READ_BYTES_PER_CANDIDATE, MAX_FILE_MUTATION_PLAN_SCAN_LIMIT,
};
mod service_request;
pub use binding::{AuditBinding, AuditBindingState};
pub use io_evidence::IoMaterialReservation;
pub use service_authority_lock::{
    ServiceAuthorityControl, ServiceAuthorityLease, ServiceAuthorityResource,
};
mod read_archive;
mod read_archive_budget;
mod read_archive_cursor;
mod read_archive_retention;
pub use read_archive_cursor::{ArchivePage, MAX_ARCHIVE_PAGE_BYTES, ReadArchiveCursor};
mod read_capture;
mod read_journal;
mod records;
mod seals;
const APPLICATION_ID: i64 = 0x4d4f5252;
const BASE_SCHEMA: &str = "CREATE TABLE cards (id TEXT PRIMARY KEY, payload BLOB NOT NULL) STRICT;
                CREATE TABLE operations (id TEXT PRIMARY KEY, card_id TEXT NOT NULL, object_kind INTEGER NOT NULL DEFAULT 0, payload BLOB NOT NULL) STRICT;
                CREATE INDEX operation_card ON operations(card_id);
                CREATE TABLE outbox (sequence INTEGER PRIMARY KEY AUTOINCREMENT, id TEXT UNIQUE NOT NULL REFERENCES operations(id), payload BLOB NOT NULL) STRICT;
                PRAGMA application_id=1297044050; PRAGMA user_version=4;";
/// Latest supported persistent Store schema; historical feature floors stay fixed.
pub const SCHEMA_VERSION: i64 = 25;
#[derive(Clone, Copy)]
pub struct EventBudget {
    pub max_count: u32,
    pub max_bytes: u64,
}
impl Default for EventBudget {
    fn default() -> Self {
        Self {
            max_count: 1024,
            max_bytes: 64 * 1024 * 1024,
        }
    }
}
pub struct Store {
    connection: Connection,
    service_authority_coordinator: service_authority_lock::ServiceAuthorityCoordinator,
    budget: EventBudget,
    retention_budget: crate::read_archive::RetentionBudget,
    audit_trust: Option<crate::audit::TrustedLog>,
    snapshot_origin: Option<std::path::PathBuf>,
    snapshot_identity: std::sync::Arc<()>,
    changes_liveness: std::sync::Arc<()>,
}
fn sql<T>(value: rusqlite::Result<T>) -> Result<T> {
    value.map_err(|error| {
        #[cfg(all(target_arch = "wasm32", feature = "web-test-hooks"))]
        web_boundary(&format!("sqlite-error:{error:?}"));
        #[cfg(test)]
        eprintln!("SQLITE-ERROR-DEBUG: {error:?}");
        match error.sqlite_error_code() {
            Some(rusqlite::ErrorCode::DiskFull) => Error::StorageFull,
            Some(rusqlite::ErrorCode::DatabaseBusy | rusqlite::ErrorCode::DatabaseLocked) => {
                Error::StorageBusy
            }
            _ => Error::Storage,
        }
    })
}
// Failpoints are excluded from default production builds and require an explicit feature.
#[cfg(all(target_arch = "wasm32", feature = "web-test-hooks"))]
#[wasm_bindgen::prelude::wasm_bindgen]
extern "C" {
    #[wasm_bindgen::prelude::wasm_bindgen(js_name=__morrowFaultBoundary)]
    fn web_boundary(name: &str);
}
fn boundary(_name: &str) {
    #[cfg(all(target_arch = "wasm32", feature = "web-test-hooks"))]
    web_boundary(_name);
    #[cfg(feature = "fault-injection")]
    if std::env::var("MORROW_TEST_CRASH_AT").as_deref() == Ok(_name) {
        // No stack unwinding or connection drop; tests recover in a fresh process.
        std::process::exit(86);
    }
}
fn blob(connection: &Connection, query: &str, id: &str, limit: usize) -> Result<Option<Vec<u8>>> {
    let mut statement = sql(connection.prepare(query))?;
    let value = sql(statement
        .query_row([id], |row| {
            let bytes = row.get_ref(0)?.as_blob()?;
            Ok(if bytes.len() > limit {
                None
            } else {
                Some(bytes.to_vec())
            })
        })
        .optional())?;
    match value {
        Some(None) => Err(Error::Limit),
        Some(Some(v)) => Ok(Some(v)),
        None => Ok(None),
    }
}
/// Single shared logical capacity entry for every outbox writer. Pre-dispatch
/// IO intent reservations and stored/protected IO material reduce the room
/// other events may consume, so a dispatched operation can never be crowded
/// out by later writes. This is a logical quota; SQLite reporting DiskFull
/// still maps to StorageFull.
pub(super) fn event_room(c: &Connection, budget: EventBudget, incoming_bytes: u64) -> Result<()> {
    capacity_room(c, budget, incoming_bytes, true)
}
/// Material admission consumes bytes but creates no outbox event.
pub(super) fn byte_room(c: &Connection, budget: EventBudget, incoming_bytes: u64) -> Result<()> {
    capacity_room(c, budget, incoming_bytes, false)
}
fn capacity_room(
    c: &Connection,
    budget: EventBudget,
    incoming_bytes: u64,
    event: bool,
) -> Result<()> {
    let (count, bytes): (i64, i64) = sql(c.query_row(
        "SELECT count(*),coalesce(sum(length(payload)),0) FROM outbox",
        [],
        |r| Ok((r.get(0)?, r.get(1)?)),
    ))?;
    let (reserved_events, reserved_bytes) = io_intent::reservations(c)?;
    let material_bytes = u64::try_from(io_evidence::accounted(c)?).map_err(|_| Error::Integrity)?;
    if (event && count.saturating_add(reserved_events) >= i64::from(budget.max_count))
        || (bytes as u64)
            .saturating_add(reserved_bytes as u64)
            .saturating_add(material_bytes)
            .saturating_add(service_config::accounted(c)?)
            .saturating_add(service_authority::accounted(c)?)
            .saturating_add(outbound_authority::accounted(c)?)
            .saturating_add(tls_identity::accounted(c)?)
            .saturating_add(file_content::accounted(c)?)
            .saturating_add(channel_journal::accounted(c)?)
            .saturating_add(agent_ledger::accounted(c)?)
            .saturating_add(incoming_bytes)
            > budget.max_bytes
    {
        return Err(Error::EventCapacity);
    }
    Ok(())
}
fn read_card(connection: &Connection, id: &str) -> Result<Option<CardRecord>> {
    let bytes = blob(
        connection,
        "SELECT payload FROM cards WHERE id=?1",
        id,
        envelope::MAX_CONTAINER_BYTES,
    )?;
    bytes
        .map(|v| {
            let card = envelope::decode(&v)?;
            if card.summary().id != id {
                return Err(Error::Integrity);
            }
            Ok(card)
        })
        .transpose()
}
fn read_commit(connection: &Connection, id: &str) -> Result<Option<Vec<u8>>> {
    blob(
        connection,
        "SELECT payload FROM operations WHERE id=?1",
        id,
        transaction::MAX_EVENT_BYTES + transaction::MAX_EVENT_BYTES / 255 + 128,
    )
}
// A shared SQL routine never owns transaction control. Portable Store retains
// its original commit/drop policy; the protected adapter owns verified exits.
enum StoreMutation<T> {
    Commit(T),
    Unchanged(T),
}
fn lookup_connection(connection: &Connection, operation_id: &str) -> Result<Lookup> {
    identity(operation_id)?;
    match read_commit(connection, operation_id)? {
        Some(raw) => {
            let (_, receipt) = transaction::decode_commit(&raw)?;
            if receipt.operation_id != operation_id {
                return Err(Error::Integrity);
            }
            Ok(Lookup::Committed(receipt))
        }
        None => Ok(Lookup::Absent),
    }
}

fn lookup_for_card_connection(
    connection: &Connection,
    card_id: &str,
    operation_id: &str,
) -> Result<Lookup> {
    identity(card_id)?;
    identity(operation_id)?;
    let mut statement = sql(connection
        .prepare("SELECT payload FROM operations WHERE id=?1 AND card_id=?2 AND object_kind=0"))?;
    let value = sql(statement
        .query_row(params![operation_id, card_id], |row| {
            let bytes = row.get_ref(0)?.as_blob()?;
            Ok(
                if bytes.len()
                    <= transaction::MAX_EVENT_BYTES + transaction::MAX_EVENT_BYTES / 255 + 128
                {
                    Some(bytes.to_vec())
                } else {
                    None
                },
            )
        })
        .optional())?;
    match value {
        None => Ok(Lookup::Absent),
        Some(None) => Err(Error::Limit),
        Some(Some(bytes)) => {
            let (_, receipt) = transaction::decode_commit(&bytes)?;
            if receipt.card_id != card_id || receipt.operation_id != operation_id {
                return Err(Error::Integrity);
            }
            Ok(Lookup::Committed(receipt))
        }
    }
}

fn pending_usage_connection(connection: &Connection) -> Result<(u64, u64)> {
    let (events, bytes): (i64, i64) = sql(connection.query_row(
        "SELECT count(*),coalesce(sum(length(payload)),0) FROM outbox",
        [],
        |row| Ok((row.get(0)?, row.get(1)?)),
    ))?;
    Ok((
        u64::try_from(events).map_err(|_| Error::Integrity)?,
        u64::try_from(bytes).map_err(|_| Error::Integrity)?,
    ))
}

fn pending_connection(
    connection: &Connection,
    after_sequence: i64,
    limit: u32,
) -> Result<Vec<(i64, Vec<u8>)>> {
    if after_sequence < 0 || limit == 0 || limit > 128 {
        return Err(Error::Limit);
    }
    let mut statement = sql(connection.prepare(
            "SELECT sequence,CASE WHEN length(payload)<=?3 THEN payload ELSE NULL END FROM outbox WHERE sequence>?1 ORDER BY sequence LIMIT ?2",
        ))?;
    let mut rows = sql(statement.query(params![
        after_sequence,
        limit,
        crate::read_journal::MAX_CONTAINER_BYTES as i64
    ]))?;
    let mut result = Vec::new();
    let mut total = 0usize;
    while let Some(row) = sql(rows.next())? {
        let raw = sql(row.get_ref(1))?;
        if matches!(raw, rusqlite::types::ValueRef::Null) {
            return Err(Error::Limit);
        }
        let value = raw.as_blob().map_err(|_| Error::Integrity)?;
        total = total.checked_add(value.len()).ok_or(Error::Limit)?;
        if total > 32 * 1024 * 1024 {
            return Err(Error::Limit);
        }
        if value.starts_with(crate::file_content_receipt::MAGIC) {
            let receipt = crate::file_content_receipt::Receipt::decode(value)?;
            file_content_receipt::verify_operation(
                connection,
                &receipt.event_id(),
                receipt.subject(),
                value,
            )?;
        } else if value.starts_with(crate::io_intent::MAGIC) {
            let record = crate::io_intent::Record::decode(value)?;
            io_intent::verify_operation(
                connection,
                &record.event_id(),
                &record.command().subject,
                value,
            )?;
        } else if value.starts_with(crate::read_journal::MAGIC) {
            let version: i64 = sql(connection.query_row("PRAGMA user_version", [], |r| r.get(0)))?;
            if version < 11 {
                return Err(Error::UnsupportedVersion);
            }
            let observation = crate::read_journal::decode(value)?;
            if version < 12 && observation.data().schema_version >= 2 {
                return Err(Error::UnsupportedVersion);
            }
            read_archive::verify_observation(connection, &observation)?;
        } else if value.starts_with(b"MORROWR1") {
            crate::records::decode_commit(value)?;
        } else {
            transaction::decode_commit(value)?;
        }
        result.push((sql(row.get(0))?, value.to_vec()));
    }
    Ok(result)
}

#[allow(clippy::too_many_arguments)]
fn apply_card_in_transaction(
    connection: &Connection,
    budget: EventBudget,
    operation_id: &str,
    card_id: &str,
    command: Vec<u8>,
    task_evidence: &[crate::task_evidence::Evidence],
    propose: impl FnOnce(Option<&CardRecord>) -> Result<CardRecord>,
    mut authorize: impl FnMut() -> Result<()>,
    create: bool,
) -> Result<StoreMutation<Receipt>> {
    boundary("after-begin");
    read_capture::reject_tracked(connection, operation_id)?;
    authorize()?;
    let evidence_digests = evidence::digests(task_evidence)?;
    if let Some(raw) = read_commit(connection, operation_id)? {
        if !raw.starts_with(b"MORROWT1") {
            return Err(Error::OperationConflict);
        }
        let (previous, receipt) = transaction::decode_commit(&raw)?;
        if previous.operation_id != operation_id {
            return Err(Error::Integrity);
        }
        if previous.command != command
            || previous
                .task_evidence_sha256
                .iter()
                .map(Vec::as_slice)
                .ne(evidence_digests.iter().map(|d| d.as_slice()))
        {
            return Err(Error::OperationConflict);
        }
        evidence::verify_retry(
            connection,
            operation_id,
            &previous.task_evidence_sha256,
            task_evidence,
        )?;
        authorize()?;
        return Ok(StoreMutation::Unchanged(receipt));
    }
    let current = read_card(connection, card_id)?;
    if create && current.is_some() {
        return Err(Error::RevisionConflict);
    }
    let next = propose(current.as_ref())?;
    let event = transaction::encode_commit_with_evidence(command, &next, &evidence_digests)?;
    let receipt = transaction::decode_commit(&event)?.1;
    event_room(connection, budget, event.len() as u64)?;
    let payload = envelope::encode(&next)?;
    sql(connection.execute("INSERT INTO cards(id,payload) VALUES(?1,?2) ON CONFLICT(id) DO UPDATE SET payload=excluded.payload", params![card_id, payload]))?;
    boundary("after-card");
    sql(connection.execute(
        "INSERT INTO operations(id,card_id,payload) VALUES(?1,?2,?3)",
        params![operation_id, card_id, event],
    ))?;
    boundary("after-operation");
    sql(connection.execute(
        "INSERT INTO outbox(id,payload) VALUES(?1,?2)",
        params![operation_id, event],
    ))?;
    sql(connection.execute(
        "INSERT INTO operation_events(sequence,id) VALUES(last_insert_rowid(),?1)",
        [operation_id],
    ))?;
    boundary("after-event");
    blobs::bind(connection, &next, operation_id)?;
    evidence::bind(connection, operation_id, task_evidence)?;
    boundary("after-task-evidence");
    // The host is exclusively borrowed throughout. Revocation and commit are serialized.
    // A fresh host clock tick rejects expiry during synchronous preparation/I/O.
    authorize()?;
    boundary("before-commit");
    Ok(StoreMutation::Commit(receipt))
}

// Authority locking depends on the actual native database, not snapshot support
// or journal mode. Unknown native adapters must never become no-op writers.
#[cfg(not(target_arch = "wasm32"))]
fn native_service_authority_supported(
    connection: &Connection,
    path: &Path,
    vfs: Option<&str>,
) -> Result<bool> {
    let actual: String = sql(connection.query_row(
        "SELECT file FROM pragma_database_list WHERE name='main'",
        [],
        |r| r.get(0),
    ))?;
    if actual.is_empty() {
        return if vfs.is_none() && path == Path::new(":memory:") {
            Ok(false)
        } else {
            Err(Error::Invalid("unidentified native authority store"))
        };
    }
    // If a custom native VFS cannot prove a real local backing file, reject the
    // adapter. A profile with no supported live pin must not bypass writers.
    let actual = std::fs::canonicalize(actual).map_err(|_| Error::Io)?;
    if !actual.is_file() {
        return Err(Error::Invalid("native authority store file"));
    }
    Ok(true)
}
#[cfg(target_arch = "wasm32")]
fn native_service_authority_supported(_: &Connection, _: &Path, _: Option<&str>) -> Result<bool> {
    Ok(false)
}
impl Store {
    /// Reserved fail-closed Linux private storage entry point. Usable admission
    /// requires a reviewed proof of SQLite's actually opened inode before SQL,
    /// plus transaction and snapshot guards. It is deliberately unavailable.
    /// Generic `open` is not a protected substitute or fallback.
    #[cfg(target_os = "linux")]
    pub fn open_private(_path: &Path, _budget: EventBudget, _create: bool) -> Result<Self> {
        Err(Error::Invalid("protected Linux SQLite admission unavailable"))
    }
    #[cfg(target_os = "linux")]
    pub fn open_private_audited(
        _path: &Path,
        _budget: EventBudget,
        _create: bool,
        _trust: crate::audit::TrustedLog,
    ) -> Result<Self> {
        Err(Error::Invalid("protected Linux SQLite admission unavailable"))
    }
    #[cfg(target_os = "linux")]
    pub fn open_private_read_only_audited(
        _path: &Path,
        _trust: crate::audit::TrustedLog,
    ) -> Result<Self> {
        Err(Error::Invalid("protected Linux SQLite admission unavailable"))
    }
    #[cfg(target_os = "linux")]
    pub fn private_audit_binding_status(_path: &Path) -> Result<AuditBindingState> {
        Err(Error::Invalid("protected Linux SQLite admission unavailable"))
    }
    /// Pin this file-backed Store before resolving persisted service approvals.
    pub fn pin_service_authority(&mut self) -> Result<ServiceAuthorityLease> {
        self.service_authority_coordinator.pin()
    }
    /// Narrow a current all-writes resolution guard to its exact loaded records.
    /// Does not grant IO or allow a scoped lease to expand its dependencies.
    pub fn narrow_service_authority(
        &self,
        guard: &ServiceAuthorityLease,
        resources: &[ServiceAuthorityResource],
    ) -> Result<ServiceAuthorityLease> {
        self.service_authority_coordinator.narrow(guard, resources)
    }
    pub fn validate_service_authority(&self, lease: &ServiceAuthorityLease) -> Result<()> {
        self.service_authority_coordinator.validate(lease)
    }
    pub fn service_authority_control(&self) -> ServiceAuthorityControl {
        self.service_authority_coordinator.control()
    }

    #[cfg(not(target_arch = "wasm32"))]
    pub fn open(path: &Path, budget: EventBudget) -> Result<Self> {
        Self::open_mode(path, budget, true)
    }
    #[cfg(not(target_arch = "wasm32"))]
    pub fn open_existing(path: &Path, budget: EventBudget) -> Result<Self> {
        Self::open_mode(path, budget, false)
    }
    #[cfg(not(target_arch = "wasm32"))]
    fn open_mode(path: &Path, budget: EventBudget, create: bool) -> Result<Self> {
        Self::open_adapter(path, budget, create, None, false, None)
    }
    /// Independent native verification: no creation, migration or journal changes.
    #[cfg(not(target_arch = "wasm32"))]
    pub fn open_read_only_audited(path: &Path, trust: crate::audit::TrustedLog) -> Result<Self> {
        let connection = sql(Connection::open_with_flags(
            path,
            rusqlite::OpenFlags::SQLITE_OPEN_READ_ONLY | rusqlite::OpenFlags::SQLITE_OPEN_NO_MUTEX,
        ))?;
        sql(connection.busy_timeout(Duration::ZERO))?;
        let app: i64 = sql(connection.query_row("PRAGMA application_id", [], |r| r.get(0)))?;
        let version: i64 = sql(connection.query_row("PRAGMA user_version", [], |r| r.get(0)))?;
        if app != APPLICATION_ID || !matches!(version, 5..=SCHEMA_VERSION) {
            return Err(Error::UnsupportedVersion);
        }
        let snapshot_origin = card_snapshot::origin(&connection, true)?;
        let authority_store_id = service_authority::store_identity(&connection)?;
        let authority_native = native_service_authority_supported(&connection, path, None)?;
        let service_authority_coordinator =
            service_authority_lock::ServiceAuthorityCoordinator::new(
                authority_store_id.unwrap_or([0; 32]),
                authority_store_id.is_some() && authority_native,
            );
        let store = Self {
            service_authority_coordinator,
            snapshot_origin,
            snapshot_identity: std::sync::Arc::new(()),
            changes_liveness: std::sync::Arc::new(()),
            retention_budget: Default::default(),
            connection,
            budget: EventBudget::default(),
            audit_trust: Some(trust),
        };
        store.integrity_check()?;
        Ok(store)
    }
    /// Host-selected OPFS adapter; missing named VFS is an error, never memory fallback.
    #[cfg(all(target_arch = "wasm32", feature = "web-storage"))]
    pub fn open_opfs(path: &Path, budget: EventBudget, create: bool) -> Result<Self> {
        Self::open_adapter(path, budget, create, Some("morrow-opfs"), true, None)
    }
    /// Native qualification of the exclusive rollback-journal transaction profile.
    #[cfg(not(target_arch = "wasm32"))]
    pub fn open_exclusive(path: &Path, budget: EventBudget, create: bool) -> Result<Self> {
        Self::open_adapter(path, budget, create, None, true, None)
    }
    /// Host-pinned identity for reading or sealing an audited database.
    #[cfg(not(target_arch = "wasm32"))]
    pub fn open_audited(
        path: &Path,
        budget: EventBudget,
        create: bool,
        trust: crate::audit::TrustedLog,
    ) -> Result<Self> {
        Self::open_adapter(path, budget, create, None, false, Some(trust))
    }
    #[cfg(all(target_arch = "wasm32", feature = "web-storage"))]
    pub fn open_opfs_audited(
        path: &Path,
        budget: EventBudget,
        create: bool,
        trust: crate::audit::TrustedLog,
    ) -> Result<Self> {
        Self::open_adapter(path, budget, create, Some("morrow-opfs"), true, Some(trust))
    }
    fn open_adapter(
        path: &Path,
        budget: EventBudget,
        create: bool,
        vfs: Option<&str>,
        exclusive: bool,
        audit_trust: Option<crate::audit::TrustedLog>,
    ) -> Result<Self> {
        let mut flags =
            rusqlite::OpenFlags::SQLITE_OPEN_READ_WRITE | rusqlite::OpenFlags::SQLITE_OPEN_NO_MUTEX;
        if create {
            flags |= rusqlite::OpenFlags::SQLITE_OPEN_CREATE;
        }
        let mut connection = sql(match vfs {
            Some(name) => Connection::open_with_flags_and_vfs(path, flags, name),
            None => Connection::open_with_flags(path, flags),
        })?;
        sql(connection.busy_timeout(Duration::ZERO))?;
        let authority_native = native_service_authority_supported(&connection, path, vfs)?;
        // Reject unrelated and future databases before changing their pragmas/schema.
        let app: i64 = sql(connection.query_row("PRAGMA application_id", [], |r| r.get(0)))?;
        let version: i64 = sql(connection.query_row("PRAGMA user_version", [], |r| r.get(0)))?;
        if !(app == 0 && version == 0 && create)
            && (app != APPLICATION_ID || !matches!(version, 4..=SCHEMA_VERSION))
        {
            return Err(Error::UnsupportedVersion);
        }
        if app == 0 && version == 0 && create {
            let tables: i64 = sql(connection.query_row(
                "SELECT count(*) FROM sqlite_schema WHERE name NOT LIKE 'sqlite_%'",
                [],
                |r| r.get(0),
            ))?;
            if tables != 0 {
                return Err(Error::Invalid("unrelated database"));
            }
        }
        // A current, bound native WAL database needs no migration or rebinding.
        // Validate once under the writer transaction, before any index change.
        // This proof is local to this open; no persisted validation flag or
        // alternate public unchecked-open API is introduced.
        if !exclusive
            && vfs.is_none()
            && version == SCHEMA_VERSION
            && let Some(trust) = audit_trust.as_ref()
        {
            let mode: String = sql(connection.query_row("PRAGMA journal_mode", [], |r| r.get(0)))?;
            if mode == "wal" {
                sql(connection.pragma_update(None, "foreign_keys", true))?;
                sql(connection.pragma_update(None, "trusted_schema", false))?;
                sql(connection.pragma_update(None, "synchronous", "FULL"))?;
                let tx = sql(connection.transaction_with_behavior(TransactionBehavior::Immediate))?;
                let locked_version: i64 =
                    sql(tx.query_row("PRAGMA user_version", [], |r| r.get(0)))?;
                let locked_app: i64 = sql(tx.query_row("PRAGMA application_id", [], |r| r.get(0)))?;
                if locked_version != version || locked_app != app {
                    return Err(Error::Integrity);
                }
                if binding::read(&tx)?.is_some() {
                    Self::integrity_connection(&tx, Some(trust))?;
                    // Existing binding: verifies the pinned identity and key
                    // strength without writing a new binding.
                    binding::bind(&tx, trust)?;
                    sql(tx.execute_batch(read_archive_budget::INDEX))?;
                    boundary("binding-before-commit");
                    tx.commit().map_err(|_| Error::CommitUnknown)?;
                    boundary("binding-after-commit");
                    return Self::from_open_connection(
                        connection,
                        budget,
                        audit_trust,
                        true,
                        authority_native,
                    );
                }
            }
        }
        if exclusive {
            let locking: String =
                sql(connection.query_row("PRAGMA locking_mode=EXCLUSIVE", [], |r| r.get(0)))?;
            if locking != "exclusive" {
                return Err(Error::Invalid("exclusive locking unavailable"));
            }
            let journal: String =
                sql(connection.query_row("PRAGMA journal_mode=DELETE", [], |r| r.get(0)))?;
            if journal != "delete" {
                return Err(Error::Invalid("rollback journal unavailable"));
            }
        }
        sql(connection.pragma_update(None, "synchronous", "FULL"))?;
        if app == 0 && version == 0 && create {
            let tx = sql(connection.transaction_with_behavior(TransactionBehavior::Immediate))?;
            let tables: i64 = sql(tx.query_row(
                "SELECT count(*) FROM sqlite_schema WHERE name NOT LIKE 'sqlite_%'",
                [],
                |r| r.get(0),
            ))?;
            if tables != 0 {
                return Err(Error::Invalid("unrelated database"));
            }
            sql(tx.execute_batch(BASE_SCHEMA))?;
            sql(tx.execute_batch(blobs::SCHEMA))?;
            sql(tx.execute_batch(records::SCHEMA))?;
            sql(tx.commit())?;
        } else if app != APPLICATION_ID || !matches!(version, 4..=SCHEMA_VERSION) {
            return Err(Error::UnsupportedVersion);
        }
        if version == 4 || (app == 0 && version == 0 && create) {
            let tx = sql(connection.transaction_with_behavior(TransactionBehavior::Immediate))?;
            sql(tx.execute_batch(seals::SCHEMA))?;
            sql(tx.execute(
                "INSERT INTO operation_events(sequence,id) SELECT sequence,id FROM outbox",
                [],
            ))?;
            boundary("seal-migration-after-index");
            Self::integrity_connection(&tx, audit_trust.as_ref())?;
            sql(tx.pragma_update(None, "user_version", 5))?;
            boundary("seal-migration-before-commit");
            tx.commit().map_err(|_| Error::CommitUnknown)?;
            boundary("seal-migration-after-commit");
        }
        // Bind identity before any audited caller can publish a content event.
        // A v5 signed database must first verify with caller-supplied trust.
        if version < 6 {
            let tx = sql(connection.transaction_with_behavior(TransactionBehavior::Immediate))?;
            Self::integrity_connection(&tx, audit_trust.as_ref())?;
            sql(tx.execute_batch(binding::SCHEMA))?;
            if let Some(trust) = audit_trust.as_ref() {
                binding::bind(&tx, trust)?;
            }
            sql(tx.pragma_update(None, "user_version", 6))?;
            Self::integrity_connection(&tx, audit_trust.as_ref())?;
            boundary("binding-before-commit");
            tx.commit().map_err(|_| Error::CommitUnknown)?;
            boundary("binding-after-commit");
        } else if let Some(trust) = audit_trust.as_ref() {
            let tx = sql(connection.transaction_with_behavior(TransactionBehavior::Immediate))?;
            Self::integrity_connection(&tx, Some(trust))?;
            binding::bind(&tx, trust)?;
            boundary("binding-before-commit");
            tx.commit().map_err(|_| Error::CommitUnknown)?;
            boundary("binding-after-commit");
        }
        if version < 7 {
            let tx = sql(connection.transaction_with_behavior(TransactionBehavior::Immediate))?;
            Self::integrity_connection(&tx, audit_trust.as_ref())?;
            sql(tx.execute_batch(evidence::SCHEMA))?;
            sql(tx.pragma_update(None, "user_version", 7))?;
            Self::integrity_connection(&tx, audit_trust.as_ref())?;
            boundary("evidence-migration-before-commit");
            tx.commit().map_err(|_| Error::CommitUnknown)?;
            boundary("evidence-migration-after-commit");
        }
        if version < 8 {
            let tx = sql(connection.transaction_with_behavior(TransactionBehavior::Immediate))?;
            Self::integrity_connection(&tx, audit_trust.as_ref())?;
            evidence_chunks::migrate(&tx)?;
            sql(tx.pragma_update(None, "user_version", 8))?;
            Self::integrity_connection(&tx, audit_trust.as_ref())?;
            boundary("evidence-chunks-migration-before-commit");
            tx.commit().map_err(|_| Error::CommitUnknown)?;
            boundary("evidence-chunks-migration-after-commit");
        }
        if version < 9 {
            let tx = sql(connection.transaction_with_behavior(TransactionBehavior::Immediate))?;
            Self::integrity_connection(&tx, audit_trust.as_ref())?;
            sql(tx.pragma_update(None, "user_version", 9))?;
            Self::integrity_connection(&tx, audit_trust.as_ref())?;
            boundary("batch-evidence-migration-before-commit");
            tx.commit().map_err(|_| Error::CommitUnknown)?;
            boundary("batch-evidence-migration-after-commit");
        }
        if version < 10 {
            let tx = sql(connection.transaction_with_behavior(TransactionBehavior::Immediate))?;
            Self::integrity_connection(&tx, audit_trust.as_ref())?;
            sql(tx.pragma_update(None, "user_version", 10))?;
            Self::integrity_connection(&tx, audit_trust.as_ref())?;
            boundary("projection-evidence-migration-before-commit");
            tx.commit().map_err(|_| Error::CommitUnknown)?;
            boundary("projection-evidence-migration-after-commit");
        }
        if version < 11 {
            let tx = sql(connection.transaction_with_behavior(TransactionBehavior::Immediate))?;
            Self::integrity_connection(&tx, audit_trust.as_ref())?;
            sql(tx.pragma_update(None, "user_version", 11))?;
            Self::integrity_connection(&tx, audit_trust.as_ref())?;
            boundary("read-journal-migration-before-commit");
            tx.commit().map_err(|_| Error::CommitUnknown)?;
            boundary("read-journal-migration-after-commit");
        }
        if version < 12 {
            let tx = sql(connection.transaction_with_behavior(TransactionBehavior::Immediate))?;
            Self::integrity_connection(&tx, audit_trust.as_ref())?;
            sql(tx.execute_batch(read_archive::SCHEMA))?;
            sql(tx.pragma_update(None, "user_version", 12))?;
            Self::integrity_connection(&tx, audit_trust.as_ref())?;
            boundary("read-archive-migration-before-commit");
            tx.commit().map_err(|_| Error::CommitUnknown)?;
            boundary("read-archive-migration-after-commit");
        }
        if version < 13 {
            let tx = sql(connection.transaction_with_behavior(TransactionBehavior::Immediate))?;
            Self::integrity_connection(&tx, audit_trust.as_ref())?;
            sql(tx.execute_batch(read_capture::SCHEMA))?;
            sql(tx.pragma_update(None, "user_version", 13))?;
            Self::integrity_connection(&tx, audit_trust.as_ref())?;
            boundary("capture-migration-before-commit");
            tx.commit().map_err(|_| Error::CommitUnknown)?;
            boundary("capture-migration-after-commit");
        }
        if version < 14 {
            let tx = sql(connection.transaction_with_behavior(TransactionBehavior::Immediate))?;
            Self::integrity_connection(&tx, audit_trust.as_ref())?;
            read_archive_retention::migrate(&tx)?;
            sql(tx.pragma_update(None, "user_version", 14))?;
            Self::integrity_connection(&tx, audit_trust.as_ref())?;
            boundary("retention-migration-before-commit");
            tx.commit().map_err(|_| Error::CommitUnknown)?;
            boundary("retention-migration-after-commit");
        }
        if version < 15 {
            let tx = sql(connection.transaction_with_behavior(TransactionBehavior::Immediate))?;
            // Validate the entire previous schema before adding the IO namespace.
            // No existing original, commit, evidence or signature is rewritten.
            Self::integrity_connection(&tx, audit_trust.as_ref())?;
            sql(tx.execute_batch(io_intent::SCHEMA))?;
            sql(tx.pragma_update(None, "user_version", 15))?;
            Self::integrity_connection(&tx, audit_trust.as_ref())?;
            boundary("io-intent-migration-before-commit");
            tx.commit().map_err(|_| Error::CommitUnknown)?;
            boundary("io-intent-migration-after-commit");
        }
        if version < 16 {
            let tx = sql(connection.transaction_with_behavior(TransactionBehavior::Immediate))?;
            // Validate the entire v15 schema before adding the reservation
            // namespace. No existing original, commit, evidence or signature is
            // rewritten; a fresh table starts with zero held quota.
            Self::integrity_connection(&tx, audit_trust.as_ref())?;
            sql(tx.execute_batch(io_intent::reservation_schema().as_str()))?;
            sql(tx.pragma_update(None, "user_version", 16))?;
            Self::integrity_connection(&tx, audit_trust.as_ref())?;
            boundary("io-reservation-migration-before-commit");
            tx.commit().map_err(|_| Error::CommitUnknown)?;
            boundary("io-reservation-migration-after-commit");
        }
        if version < 17 {
            let tx = sql(connection.transaction_with_behavior(TransactionBehavior::Immediate))?;
            // Validate the entire v16 schema before adding the protected IO
            // material namespace. No existing original, commit, evidence or
            // signature is rewritten; fresh tables start with zero stored
            // material and zero held material quota.
            Self::integrity_connection(&tx, audit_trust.as_ref())?;
            sql(tx.execute_batch(io_evidence::SCHEMA))?;
            sql(tx.pragma_update(None, "user_version", 17))?;
            Self::integrity_connection(&tx, audit_trust.as_ref())?;
            boundary("io-evidence-migration-before-commit");
            tx.commit().map_err(|_| Error::CommitUnknown)?;
            boundary("io-evidence-migration-after-commit");
        }
        if version < 18 {
            let tx = sql(connection.transaction_with_behavior(TransactionBehavior::Immediate))?;
            Self::integrity_connection(&tx, audit_trust.as_ref())?;
            sql(tx.execute_batch(service_config::SCHEMA))?;
            sql(tx.pragma_update(None, "user_version", 18))?;
            Self::integrity_connection(&tx, audit_trust.as_ref())?;
            boundary("service-config-migration-before-commit");
            tx.commit().map_err(|_| Error::CommitUnknown)?;
            boundary("service-config-migration-after-commit");
        }
        if version < 19 {
            let tx = sql(connection.transaction_with_behavior(TransactionBehavior::Immediate))?;
            Self::integrity_connection(&tx, audit_trust.as_ref())?;
            sql(tx.execute_batch(service_authority::SCHEMA))?;
            sql(tx.execute_batch(service_authority::IDENTITY_SCHEMA))?;
            service_authority::create_identity(&tx)?;
            sql(tx.pragma_update(None, "user_version", 19))?;
            Self::integrity_connection(&tx, audit_trust.as_ref())?;
            boundary("service-authority-migration-before-commit");
            tx.commit().map_err(|_| Error::CommitUnknown)?;
            boundary("service-authority-migration-after-commit");
        }
        if version < 20 {
            let tx = sql(connection.transaction_with_behavior(TransactionBehavior::Immediate))?;
            Self::integrity_connection(&tx, audit_trust.as_ref())?;
            sql(tx.execute_batch(outbound_authority::SCHEMA))?;
            sql(tx.pragma_update(None, "user_version", 20))?;
            Self::integrity_connection(&tx, audit_trust.as_ref())?;
            boundary("outbound-authority-migration-before-commit");
            tx.commit().map_err(|_| Error::CommitUnknown)?;
            boundary("outbound-authority-migration-after-commit");
        }
        if version < 21 {
            let tx = sql(connection.transaction_with_behavior(TransactionBehavior::Immediate))?;
            Self::integrity_connection(&tx, audit_trust.as_ref())?;
            sql(tx.execute_batch(tls_identity::SCHEMA))?;
            sql(tx.pragma_update(None, "user_version", 21))?;
            Self::integrity_connection(&tx, audit_trust.as_ref())?;
            boundary("tls-identity-migration-before-commit");
            tx.commit().map_err(|_| Error::CommitUnknown)?;
            boundary("tls-identity-migration-after-commit");
        }
        if version < 22 {
            let tx = sql(connection.transaction_with_behavior(TransactionBehavior::Immediate))?;
            Self::integrity_connection(&tx, audit_trust.as_ref())?;
            sql(tx.execute_batch(file_content::SCHEMA))?;
            sql(tx.pragma_update(None, "user_version", 22))?;
            Self::integrity_connection(&tx, audit_trust.as_ref())?;
            boundary("file-content-migration-before-commit");
            tx.commit().map_err(|_| Error::CommitUnknown)?;
            boundary("file-content-migration-after-commit");
        }
        if version < 23 {
            let tx = sql(connection.transaction_with_behavior(TransactionBehavior::Immediate))?;
            Self::integrity_connection(&tx, audit_trust.as_ref())?;
            sql(tx.execute_batch(file_content_receipt::SCHEMA))?;
            sql(tx.pragma_update(None, "user_version", 23))?;
            file_content_receipt::migrate(&tx, budget)?;
            Self::integrity_connection(&tx, audit_trust.as_ref())?;
            boundary("file-content-receipt-migration-before-commit");
            tx.commit().map_err(|_| Error::CommitUnknown)?;
            boundary("file-content-receipt-migration-after-commit");
        }
        if version < 24 {
            let tx = sql(connection.transaction_with_behavior(TransactionBehavior::Immediate))?;
            Self::integrity_connection(&tx, audit_trust.as_ref())?;
            channel_journal::create(&tx)?;
            sql(tx.pragma_update(None, "user_version", 24))?;
            Self::integrity_connection(&tx, audit_trust.as_ref())?;
            boundary("channel-journal-migration-before-commit");
            tx.commit().map_err(|_| Error::CommitUnknown)?;
            boundary("channel-journal-migration-after-commit");
        }
        if version < 25 {
            let tx = sql(connection.transaction_with_behavior(TransactionBehavior::Immediate))?;
            Self::integrity_connection(&tx, audit_trust.as_ref())?;
            sql(tx.execute_batch(agent_ledger::SCHEMA))?;
            sql(tx.pragma_update(None, "user_version", 25))?;
            Self::integrity_connection(&tx, audit_trust.as_ref())?;
            boundary("agent-ledger-migration-before-commit");
            tx.commit().map_err(|_| Error::CommitUnknown)?;
            boundary("agent-ledger-migration-after-commit");
        }
        // Rebuildable SQLite access index; no business-payload change.
        sql(connection.execute_batch(read_archive_budget::INDEX))?;
        sql(connection.pragma_update(None, "foreign_keys", true))?;
        sql(connection.pragma_update(None, "trusted_schema", false))?;
        if !exclusive {
            let mode: String =
                sql(connection.query_row("PRAGMA journal_mode=WAL", [], |r| r.get(0)))?;
            if mode != "wal" {
                return Err(Error::Invalid("WAL unavailable"));
            }
        }
        sql(connection.pragma_update(None, "synchronous", "FULL"))?;
        let store = Self::from_open_connection(
            connection,
            budget,
            audit_trust,
            !exclusive && vfs.is_none(),
            authority_native,
        )?;
        store.integrity_check()?;
        Ok(store)
    }
    /// Assemble connection-local helpers. Callers must verify this open before
    /// returning it; only the current bound WAL path has already done so.
    fn from_open_connection(
        connection: Connection,
        budget: EventBudget,
        audit_trust: Option<crate::audit::TrustedLog>,
        snapshots: bool,
        authority_native: bool,
    ) -> Result<Self> {
        let snapshot_origin = card_snapshot::origin(&connection, snapshots)?;
        let authority_store_id = service_authority::store_identity(&connection)?;
        let service_authority_coordinator =
            service_authority_lock::ServiceAuthorityCoordinator::new(
                authority_store_id.unwrap_or([0; 32]),
                authority_store_id.is_some() && authority_native,
            );
        Ok(Self {
            service_authority_coordinator,
            snapshot_origin,
            snapshot_identity: std::sync::Arc::new(()),
            changes_liveness: std::sync::Arc::new(()),
            retention_budget: Default::default(),
            connection,
            budget,
            audit_trust,
        })
    }
    pub fn card(&self, id: &str) -> Result<Option<CardRecord>> {
        identity(id)?;
        read_card(&self.connection, id)
    }
    /// Host-only query. A transport must apply its read permissions before exposing this.
    pub fn lookup(&self, operation_id: &str) -> Result<Lookup> {
        lookup_connection(&self.connection, operation_id)
    }
    /// Scoped before payload access: a receipt for another card is indistinguishable from absence.
    pub fn lookup_for_card(&self, card_id: &str, operation_id: &str) -> Result<Lookup> {
        lookup_for_card_connection(&self.connection, card_id, operation_id)
    }
    /// Host-local creation only. Not a public plugin command or migration entry point.
    /// Every attachment must already exist as a verified staged payload.
    pub fn create_local(&mut self, operation_id: &str, card: &CardRecord) -> Result<Receipt> {
        let command = transaction::create_command(operation_id, card)?;
        let id = card.summary().id;
        self.apply(
            operation_id,
            &id,
            command,
            &[],
            |_| Ok(card.clone()),
            || Ok(()),
            true,
        )
    }
    pub fn set_attachments_local(
        &mut self,
        operation_id: &str,
        card_id: &str,
        expected_revision: u64,
        attachments: &[crate::content::Attachment],
    ) -> Result<Receipt> {
        let command = transaction::set_attachments_command(
            operation_id,
            card_id,
            expected_revision,
            attachments,
        )?;
        self.apply(
            operation_id,
            card_id,
            command,
            &[],
            |card| {
                card.ok_or(Error::NotFound)?
                    .with_attachments(expected_revision, attachments)
            },
            || Ok(()),
            false,
        )
    }
    pub(crate) fn create_authorized_with_evidence(
        &mut self,
        operation_id: &str,
        card: &CardRecord,
        evidence: &[crate::task_evidence::Evidence],
        authorize: impl FnMut() -> Result<()>,
    ) -> Result<Receipt> {
        if card.summary().revision != 1 {
            return Err(Error::Invalid("creation revision"));
        }
        let command = transaction::create_command(operation_id, card)?;
        self.apply(
            operation_id,
            &card.summary().id,
            command,
            evidence,
            |_| Ok(card.clone()),
            authorize,
            true,
        )
    }
    pub(crate) fn edit_content_with_evidence(
        &mut self,
        change: &crate::content_change::ContentChange,
        evidence: &[crate::task_evidence::Evidence],
        authorize: impl FnMut() -> Result<()>,
    ) -> Result<Receipt> {
        let command = transaction::content_command(change)?;
        self.apply(
            &change.operation_id,
            &change.card_id,
            command,
            evidence,
            |card| {
                let current = card.ok_or(Error::NotFound)?;
                // This is a live-write constraint only. Schema 1 SetContent has no source
                // format; its historical proposal and event decoding remain unchanged.
                if current.summary().format_version != 1 {
                    return Err(Error::UnsupportedVersion);
                }
                change.propose(current)
            },
            authorize,
            false,
        )
    }
    pub(crate) fn edit_versioned_content_with_evidence(
        &mut self,
        change: &crate::versioned_content_change::VersionedContentChange,
        evidence: &[crate::task_evidence::Evidence],
        authorize: impl FnMut() -> Result<()>,
    ) -> Result<Receipt> {
        let command = transaction::versioned_content_command(change)?;
        self.apply(
            &change.operation_id,
            &change.source()?.summary().id,
            command,
            evidence,
            |card| change.propose(card.ok_or(Error::NotFound)?),
            authorize,
            false,
        )
    }
    pub(crate) fn migrate_content_with_evidence(
        &mut self,
        change: &crate::content_migration::ContentMigration,
        evidence: &[crate::task_evidence::Evidence],
        authorize: impl FnMut() -> Result<()>,
    ) -> Result<Receipt> {
        let command = transaction::migration_command(change)?;
        self.apply(
            &change.operation_id,
            &change.source()?.summary().id,
            command,
            evidence,
            |card| change.propose(card.ok_or(Error::NotFound)?),
            authorize,
            false,
        )
    }
    /// Trusted bounded index for host discovery. Returning IDs does not grant
    /// plugins read access; each resulting object still needs authorization.
    pub fn card_ids_local(&self, after: &str, limit: u32) -> Result<Vec<String>> {
        if limit == 0 || limit > 128 {
            return Err(Error::Limit);
        }
        if !after.is_empty() {
            identity(after)?;
        }
        let mut stmt = sql(self
            .connection
            .prepare("SELECT id FROM cards WHERE id>?1 ORDER BY id LIMIT ?2"))?;
        let rows = sql(stmt.query_map(params![after, limit], |r| r.get(0)))?;
        rows.map(sql).collect()
    }
    pub(crate) fn rename(
        &mut self,
        request: &RenameRequest,
        authorize: impl FnMut() -> Result<()>,
    ) -> Result<Receipt> {
        let command = transaction::rename_command(request)?;
        self.apply(
            &request.operation_id,
            &request.card_id,
            command,
            &[],
            |current| request.propose(current.ok_or(Error::NotFound)?),
            authorize,
            false,
        )
    }
    #[allow(clippy::too_many_arguments)]
    fn apply(
        &mut self,
        operation_id: &str,
        card_id: &str,
        command: Vec<u8>,
        task_evidence: &[crate::task_evidence::Evidence],
        propose: impl FnOnce(Option<&CardRecord>) -> Result<CardRecord>,
        authorize: impl FnMut() -> Result<()>,
        create: bool,
    ) -> Result<Receipt> {
        let tx = sql(self
            .connection
            .transaction_with_behavior(TransactionBehavior::Immediate))?;
        match apply_card_in_transaction(
            &tx,
            self.budget,
            operation_id,
            card_id,
            command,
            task_evidence,
            propose,
            authorize,
            create,
        )? {
            StoreMutation::Unchanged(receipt) => Ok(receipt),
            StoreMutation::Commit(receipt) => {
                tx.commit().map_err(|_| Error::CommitUnknown)?;
                boundary("after-commit");
                Ok(receipt)
            }
        }
    }
    /// Engine-consistent snapshot into a new staging file. A failed partial file
    /// must never be published by the caller; this does not modify the source.
    #[cfg(not(target_arch = "wasm32"))]
    pub fn snapshot_to(&self, path: &Path, max_bytes: u64) -> Result<()> {
        let pinned = sql(self.connection.unchecked_transaction())?;
        let _: i64 = sql(pinned.query_row("SELECT count(*) FROM sqlite_schema", [], |r| r.get(0)))?;
        Self::integrity_connection(&pinned, self.audit_trust.as_ref())?;
        let pages: u64 = u64::try_from(sql(
            pinned.query_row("PRAGMA page_count", [], |r| r.get::<_, i64>(0))
        )?)
        .map_err(|_| Error::Integrity)?;
        let page_size: u64 = u64::try_from(sql(
            pinned.query_row("PRAGMA page_size", [], |r| r.get::<_, i64>(0))
        )?)
        .map_err(|_| Error::Integrity)?;
        if pages.checked_mul(page_size).ok_or(Error::Limit)? > max_bytes {
            return Err(Error::Limit);
        }
        let created = std::fs::File::options()
            .write(true)
            .create_new(true)
            .open(path)
            .map_err(|_| Error::Io)?;
        drop(created);
        let mut target = sql(Connection::open_with_flags(
            path,
            rusqlite::OpenFlags::SQLITE_OPEN_READ_WRITE,
        ))?;
        let backup = sql(rusqlite::backup::Backup::new(&pinned, &mut target))?;
        for _ in 0..=pages.div_ceil(128) {
            match sql(backup.step(128))? {
                rusqlite::backup::StepResult::Done => return Ok(()),
                rusqlite::backup::StepResult::More => {}
                rusqlite::backup::StepResult::Busy | rusqlite::backup::StepResult::Locked => {
                    return Err(Error::StorageBusy);
                }
                _ => return Err(Error::Storage),
            }
        }
        Err(Error::Limit)
    }
    /// Host-local queue pressure without reading or allocating event payloads.
    pub fn pending_usage(&self) -> Result<(u64, u64)> {
        pending_usage_connection(&self.connection)
    }
    /// Bounded immutable events that have not yet been atomically sealed.
    pub fn pending(&self, after_sequence: i64, limit: u32) -> Result<Vec<(i64, Vec<u8>)>> {
        pending_connection(&self.connection, after_sequence, limit)
    }
    pub fn integrity_check(&self) -> Result<()> {
        let snapshot = sql(self.connection.unchecked_transaction())?;
        Self::integrity_connection(&snapshot, self.audit_trust.as_ref())
    }
    fn integrity_connection(
        snapshot: &Connection,
        trust: Option<&crate::audit::TrustedLog>,
    ) -> Result<()> {
        #[cfg(test)]
        disk_tests::record_integrity_pass();
        let result: String = sql(snapshot.query_row("PRAGMA integrity_check", [], |r| r.get(0)))?;
        if result != "ok" {
            return Err(Error::Integrity);
        }
        io_intent::verify_schema(snapshot)?;
        io_evidence::verify_schema(snapshot)?;
        file_content::verify_schema(snapshot)?;
        file_content_receipt::verify_schema(snapshot)?;
        channel_journal::verify_schema(snapshot)?;
        agent_ledger::verify_schema(snapshot)?;
        service_config::verify_schema(snapshot)?;
        service_authority::verify_schema(snapshot)?;
        outbound_authority::verify_schema(snapshot)?;
        tls_identity::verify_schema(snapshot)?;
        read_archive_retention::verify_schema(snapshot)?;
        read_capture::verify_schema(snapshot)?;
        read_archive::verify_schema(snapshot)?;
        evidence::verify_schema(snapshot)?;
        evidence_chunks::verify_schema(snapshot)?;
        binding::verify(snapshot, trust)?;
        seals::verify(snapshot, trust)?;
        let verified = open_verification::OpenVerification::new(snapshot)?;
        read_capture::verify(snapshot)?;
        read_archive_retention::verify(snapshot)?;
        io_intent::verify(snapshot)?;
        io_evidence::verify(snapshot)?;
        file_content_receipt::verify(snapshot)?;
        file_content::verify(snapshot)?;
        let mut operations = sql(snapshot.prepare(
            "SELECT id,card_id,CASE WHEN length(payload)<=?1 THEN payload ELSE NULL END,object_kind FROM operations",
        ))?;
        let mut rows = sql(operations.query([crate::read_journal::MAX_CONTAINER_BYTES as i64]))?;
        while let Some(row) = sql(rows.next())? {
            let value = sql(row.get_ref(2))?;
            if matches!(value, rusqlite::types::ValueRef::Null) {
                return Err(Error::Limit);
            }
            let raw = value.as_blob().map_err(|_| Error::Integrity)?;
            let kind: i64 = sql(row.get(3))?;
            if kind == 6 {
                file_content_receipt::verify_operation(
                    snapshot,
                    &sql(row.get::<_, String>(0))?,
                    &sql(row.get::<_, String>(1))?,
                    raw,
                )?;
                continue;
            }
            if kind == 5 {
                io_intent::verify_operation(
                    snapshot,
                    &sql(row.get::<_, String>(0))?,
                    &sql(row.get::<_, String>(1))?,
                    raw,
                )?;
                continue;
            }
            if kind == 4 {
                read_journal::verify_operation_for_open(
                    snapshot,
                    &verified,
                    &sql(row.get::<_, String>(0))?,
                    &sql(row.get::<_, String>(1))?,
                    raw,
                )?;
                continue;
            }
            if kind != 0 {
                records::verify_operation(
                    snapshot,
                    kind,
                    &sql(row.get::<_, String>(0))?,
                    &sql(row.get::<_, String>(1))?,
                    raw,
                )?;
                continue;
            }
            let (event, receipt) = transaction::decode_commit(raw)?;
            blobs::verify_event(snapshot, &receipt.operation_id, &event.attachment_sha256)?;
            verified.verify_event(&receipt.operation_id, &event.task_evidence_sha256)?;
            if receipt.operation_id != sql(row.get::<_, String>(0))?
                || receipt.card_id != sql(row.get::<_, String>(1))?
            {
                return Err(Error::Integrity);
            }
        }
        let mut cards = sql(snapshot.prepare("SELECT id,payload FROM cards"))?;
        let mut rows = sql(cards.query([]))?;
        while let Some(row) = sql(rows.next())? {
            use sha2::{Digest, Sha256};
            let id: String = sql(row.get(0))?;
            let raw = sql(row.get_ref(1))?
                .as_blob()
                .map_err(|_| Error::Integrity)?;
            let card = envelope::decode(raw)?;
            blobs::verify_card(snapshot, &card)?;
            let event = blob(snapshot,
                "SELECT o.payload FROM operations o JOIN operation_events e ON o.id=e.id WHERE o.card_id=?1 AND o.object_kind=0 ORDER BY e.sequence DESC LIMIT 1", &id,
                transaction::MAX_EVENT_BYTES + transaction::MAX_EVENT_BYTES / 255 + 128)?.ok_or(Error::Integrity)?;
            let (_, receipt) = transaction::decode_commit(&event)?;
            if card.summary().id != id
                || receipt.card_id != id
                || receipt.revision != card.summary().revision
                || receipt.content_sha256 != <[u8; 32]>::from(Sha256::digest(card.encode()))
            {
                return Err(Error::Integrity);
            }
        }
        let missing: i64 = sql(snapshot.query_row("SELECT count(*) FROM operations o LEFT JOIN cards c ON o.card_id=c.id WHERE o.object_kind=0 AND c.id IS NULL", [], |r| r.get(0)))?;
        if missing != 0 {
            return Err(Error::Integrity);
        }
        records::verify(snapshot)?;
        blobs::verify(snapshot)?;
        verified.finish()?;
        Ok(())
    }
}

#[cfg(test)]
mod disk_tests {
    use super::*;
    std::thread_local! {
        static INTEGRITY_PASSES: std::cell::Cell<usize> = const { std::cell::Cell::new(0) };
    }
    pub(super) fn record_integrity_pass() {
        INTEGRITY_PASSES.with(|count| count.set(count.get() + 1));
    }
    #[test]
    fn bound_current_wal_open_verifies_once_and_rechecks_on_every_open() {
        let dir = tempfile::tempdir().unwrap();
        let path = dir.path().join("open.db");
        let key = ed25519_dalek::SigningKey::from_bytes(&[47; 32]);
        let trust = crate::audit::TrustedLog {
            id: "open-test".into(),
            key: key.verifying_key(),
        };
        let mut store =
            Store::open_audited(&path, Default::default(), true, trust.clone()).unwrap();
        store
            .create_local(
                "create",
                &CardRecord::new("card", "text", 1, "kept", vec![1]).unwrap(),
            )
            .unwrap();
        drop(store);
        // Also exercise repair of a derived index under the verified transaction.
        let raw = Connection::open(&path).unwrap();
        raw.execute_batch("DROP INDEX read_archive_preparations")
            .unwrap();
        drop(raw);
        let writer = Connection::open(&path).unwrap();
        writer.execute_batch("BEGIN IMMEDIATE").unwrap();
        assert!(matches!(
            Store::open_audited(&path, Default::default(), false, trust.clone()),
            Err(Error::StorageBusy)
        ));
        writer.execute_batch("ROLLBACK").unwrap();
        drop(writer);
        for _ in 0..2 {
            INTEGRITY_PASSES.with(|count| count.set(0));
            let reopened =
                Store::open_audited(&path, Default::default(), false, trust.clone()).unwrap();
            assert!(reopened.card("card").unwrap().is_some());
            assert_eq!(INTEGRITY_PASSES.with(|count| count.get()), 1);
        }
        let raw = Connection::open(&path).unwrap();
        raw.execute_batch("UPDATE cards SET payload=x'01' WHERE id='card'")
            .unwrap();
        drop(raw);
        INTEGRITY_PASSES.with(|count| count.set(0));
        assert!(Store::open_audited(&path, Default::default(), false, trust).is_err());
        assert_eq!(INTEGRITY_PASSES.with(|count| count.get()), 1);
    }
    #[test]
    #[cfg(any(windows, unix))]
    fn explicit_native_vfs_uses_authority_lock_when_snapshots_are_disabled() {
        let dir = tempfile::tempdir().unwrap();
        let path = dir.path().join("vfs-owner.db");
        let mut owner = Store::open(&path, EventBudget::default()).unwrap();
        let lease = owner.pin_service_authority().unwrap();
        let copy = dir.path().join("vfs-copy.db");
        owner.snapshot_to(&copy, 32 * 1024 * 1024).unwrap();
        let vfs = if cfg!(windows) { "win32" } else { "unix" };
        let mut other =
            Store::open_adapter(&copy, EventBudget::default(), false, Some(vfs), false, None)
                .unwrap();
        assert!(other.snapshot_origin.is_none());
        let config =
            crate::service_config::Config::encode(crate::service_config::proto::Configuration {
                schema_version: 1,
                id: "locked-api".into(),
                revision: 1,
                namespace: vec![4; 32],
                retention_ms: 1000,
                service: "service.example".into(),
                handler: "api".into(),
                package_sha256: vec![5; 32],
                disabled: false,
                principals: vec![],
                approval_references: vec![],
            })
            .unwrap();
        assert_eq!(
            other.save_service_config_local(&config, 0),
            Err(Error::StorageBusy)
        );
        lease.check().unwrap();
        drop(owner);
        other.pin_service_authority().unwrap();
        other.save_service_config_local(&config, 0).unwrap();
        assert!(matches!(
            Store::open_adapter(
                &path,
                EventBudget::default(),
                false,
                Some("morrow-unregistered-vfs"),
                false,
                None
            ),
            Err(Error::Storage)
        ));
    }
    #[test]
    #[cfg(not(target_arch = "wasm32"))]
    fn native_unknown_backing_cannot_be_classified_as_memory_writer() {
        let connection = Connection::open_in_memory().unwrap();
        assert_eq!(
            native_service_authority_supported(&connection, Path::new(":memory:"), None),
            Ok(false)
        );
        assert!(
            native_service_authority_supported(&connection, Path::new("unknown.db"), None).is_err()
        );
        assert!(
            native_service_authority_supported(
                &connection,
                Path::new(":memory:"),
                Some("custom-vfs")
            )
            .is_err()
        );
    }
    #[test]
    fn sqlite_full_during_raw_stage_leaves_no_partial_blob() {
        let dir = tempfile::tempdir().unwrap();
        let mut store = Store::open(&dir.path().join("full.db"), EventBudget::default()).unwrap();
        let pages: i64 = store
            .connection
            .query_row("PRAGMA page_count", [], |r| r.get(0))
            .unwrap();
        store
            .connection
            .pragma_update(None, "max_page_count", pages)
            .unwrap();
        let result = store.stage_blob(&mut std::io::repeat(7), 1024 * 1024, None, 0);
        assert!(matches!(result, Err(Error::StorageFull)));
        assert!(store.list_blobs_local("", 128).unwrap().is_empty());
        store.integrity_check().unwrap();
    }

    #[test]
    fn sqlite_full_rolls_back_all_three_records() {
        let dir = tempfile::tempdir().unwrap();
        let mut store = Store::open(&dir.path().join("full.db"), EventBudget::default()).unwrap();
        let pages: i64 = store
            .connection
            .query_row("PRAGMA page_count", [], |r| r.get(0))
            .unwrap();
        store
            .connection
            .pragma_update(None, "max_page_count", pages)
            .unwrap();
        let mut seed = 0x12345678u32;
        let body: Vec<u8> = (0..512 * 1024)
            .map(|_| {
                seed ^= seed << 13;
                seed ^= seed >> 17;
                seed ^= seed << 5;
                seed as u8
            })
            .collect();
        let card = CardRecord::new("large", "unknown", 1, "test", body).unwrap();
        assert_eq!(store.create_local("full", &card), Err(Error::StorageFull));
        assert!(store.card("large").unwrap().is_none());
        assert_eq!(store.lookup("full").unwrap(), Lookup::Absent);
        assert!(store.pending(0, 10).unwrap().is_empty());
        store.integrity_check().unwrap();
    }

    #[test]
    fn sqlite_full_rolls_back_forward_format_migration() {
        let dir = tempfile::tempdir().unwrap();
        let mut store = Store::open(
            &dir.path().join("migration-full.db"),
            EventBudget::default(),
        )
        .unwrap();
        let original = CardRecord::new("card", "unknown", 1, "original", vec![0, 255]).unwrap();
        store.create_local("seed", &original).unwrap();
        let pages: i64 = store
            .connection
            .query_row("PRAGMA page_count", [], |r| r.get(0))
            .unwrap();
        store
            .connection
            .pragma_update(None, "max_page_count", pages)
            .unwrap();
        let mut seed = 0x12345678u32;
        let body: Vec<u8> = (0..512 * 1024)
            .map(|_| {
                seed ^= seed << 13;
                seed ^= seed >> 17;
                seed ^= seed << 5;
                seed as u8
            })
            .collect();
        let migration = crate::content_migration::ContentMigration {
            operation_id: "migrate-full".into(),
            source_card: original.encode(),
            target_format_version: 2,
            body,
            preview_text: "new preview".into(),
        };
        assert_eq!(
            store.migrate_content_with_evidence(&migration, &[], || Ok(())),
            Err(Error::StorageFull)
        );
        assert_eq!(
            store.card("card").unwrap().unwrap().encode(),
            original.encode()
        );
        assert_eq!(store.lookup("migrate-full").unwrap(), Lookup::Absent);
        assert_eq!(store.pending(0, 10).unwrap().len(), 1);
        store.integrity_check().unwrap();
    }
}
