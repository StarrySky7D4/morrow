//! Host-local durable ledger, sharing the original SQLite library and byte quota.
//! Strict CAS never treats an already committed claim as a fresh successful claim.
use super::{Store, boundary, byte_room, sql};
use crate::{
    Error, Result,
    agent_ledger::{MAX_CONTAINER_BYTES, Record},
    identity,
};
use rusqlite::{Connection, OptionalExtension, TransactionBehavior, params};

pub const MAX_RECORDS: usize = 128;
pub(super) const SCHEMA: &str = "CREATE TABLE agent_ledger(domain BLOB NOT NULL CHECK(length(domain)=32),id TEXT NOT NULL,revision INTEGER NOT NULL CHECK(revision>0),payload BLOB NOT NULL,PRIMARY KEY(domain,id)) STRICT";
fn version(c: &Connection) -> Result<i64> {
    sql(c.query_row("PRAGMA user_version", [], |row| row.get(0)))
}
pub(super) fn accounted(c: &Connection) -> Result<u64> {
    if version(c)? < 25 {
        return Ok(0);
    }
    // Keep the v25 schema and every existing container unchanged. Quota uses a
    // bounded verified scan rather than a new mutable accounting column that
    // could disagree with opaque payloads or undercharge compressible padding.
    let mut statement = sql(c.prepare(&format!("SELECT {COLUMNS} FROM agent_ledger LIMIT ?2")))?;
    let mut rows =
        sql(statement.query(params![MAX_CONTAINER_BYTES as i64, MAX_RECORDS as i64 + 1]))?;
    let mut total = 0u64;
    let mut count = 0usize;
    while let Some(row) = sql(rows.next())? {
        count += 1;
        if count > MAX_RECORDS {
            return Err(Error::Limit);
        }
        total = total
            .checked_add(decode_row(row)?.retained_bytes())
            .ok_or(Error::Limit)?;
    }
    Ok(total)
}

fn check_schema(c: &Connection) -> Result<()> {
    let stored: Option<(String, String)> = sql(c
        .query_row(
            "SELECT type,sql FROM sqlite_schema WHERE name='agent_ledger'",
            [],
            |row| Ok((row.get(0)?, row.get(1)?)),
        )
        .optional())?;
    if version(c)? < 25 {
        return if stored.is_none() {
            Ok(())
        } else {
            Err(Error::Integrity)
        };
    }
    if stored != Some(("table".into(), SCHEMA.into())) {
        return Err(Error::Integrity);
    }
    Ok(())
}
const COLUMNS: &str = "CASE WHEN typeof(domain)='blob' AND length(domain)=32 THEN domain ELSE NULL END,CASE WHEN typeof(id)='text' AND length(CAST(id AS BLOB))<=256 THEN id ELSE NULL END,revision,CASE WHEN typeof(payload)='blob' AND length(payload)<=?1 THEN payload ELSE NULL END";
fn decode_row(row: &rusqlite::Row<'_>) -> Result<Record> {
    let domain_ref = sql(row.get_ref(0))?;
    let domain = domain_ref.as_blob().map_err(|_| Error::Integrity)?;
    let id_ref = sql(row.get_ref(1))?;
    let id = id_ref.as_str().map_err(|_| Error::Integrity)?;
    let revision = sql(row.get_ref(2))?
        .as_i64()
        .map_err(|_| Error::Integrity)?;
    let payload_ref = sql(row.get_ref(3))?;
    let payload = payload_ref.as_blob().map_err(|_| Error::Integrity)?;
    let record = Record::decode(payload)?;
    if domain != record.domain()
        || id != record.id()
        || revision <= 0
        || revision as u64 != record.revision()
    {
        return Err(Error::Integrity);
    }
    Ok(record)
}
pub(super) fn verify_schema(c: &Connection) -> Result<()> {
    check_schema(c)?;
    if version(c)? < 25 {
        return Ok(());
    }
    let mut statement = sql(c.prepare(&format!("SELECT {COLUMNS} FROM agent_ledger LIMIT ?2")))?;
    let mut rows =
        sql(statement.query(params![MAX_CONTAINER_BYTES as i64, MAX_RECORDS as i64 + 1]))?;
    let mut count = 0;
    while let Some(row) = sql(rows.next())? {
        count += 1;
        if count > MAX_RECORDS {
            return Err(Error::Limit);
        }
        decode_row(row)?;
    }
    Ok(())
}
fn load(c: &Connection, domain: &[u8; 32], id: &str) -> Result<Option<Record>> {
    identity(id)?;
    if *domain == [0; 32] {
        return Err(Error::Invalid("agent ledger domain"));
    }
    check_schema(c)?;
    if version(c)? < 25 {
        return Ok(None);
    }
    let mut statement = sql(c.prepare(&format!(
        "SELECT {COLUMNS} FROM agent_ledger WHERE domain=?2 AND id=?3"
    )))?;
    let mut rows =
        sql(statement.query(params![MAX_CONTAINER_BYTES as i64, domain.as_slice(), id]))?;
    sql(rows.next())?.map(decode_row).transpose()
}
impl Store {
    /// Host-owned durable history only; no plugin transport or live grant is
    /// introduced. Historical read-only Stores before v25 return absence.
    pub fn load_agent_ledger_local(&self, domain: &[u8; 32], id: &str) -> Result<Option<Record>> {
        load(&self.connection, domain, id)
    }
    /// Expected zero inserts revision one. Every later write requires exactly
    /// current+1. Replaying an identical committed candidate conflicts: a claim
    /// must never be acquired twice through an idempotent-success shortcut.
    /// All commit errors retain CommitUnknown; callers must reconcile history
    /// and must not infer a new execution permission from a successful reload.
    pub fn compare_exchange_agent_ledger_local(
        &mut self,
        record: &Record,
        expected_revision: u64,
    ) -> Result<()> {
        if expected_revision.checked_add(1) != Some(record.revision()) {
            return Err(Error::RevisionConflict);
        }
        let _writer = self.service_authority_coordinator.writer()?;
        let tx = sql(self
            .connection
            .transaction_with_behavior(TransactionBehavior::Immediate))?;
        if !(25..=super::SCHEMA_VERSION).contains(&version(&tx)?) {
            return Err(Error::UnsupportedVersion);
        }
        let previous = load(&tx, &record.domain(), record.id())?;
        if previous.as_ref().map_or(0, Record::revision) != expected_revision {
            return Err(Error::RevisionConflict);
        }
        let count: i64 =
            sql(tx.query_row("SELECT count(*) FROM agent_ledger", [], |row| row.get(0)))?;
        if count > MAX_RECORDS as i64 || (previous.is_none() && count >= MAX_RECORDS as i64) {
            return Err(Error::Limit);
        }
        if previous.is_some() {
            let removed = sql(tx.execute(
                "DELETE FROM agent_ledger WHERE domain=?1 AND id=?2 AND revision=?3",
                params![
                    record.domain().as_slice(),
                    record.id(),
                    expected_revision as i64
                ],
            ))?;
            if removed != 1 {
                return Err(Error::RevisionConflict);
            }
        }
        // Charge reserved worst-case bytes after releasing the old row in this
        // transaction. Capacity failure rolls the entire replacement back.
        byte_room(&tx, self.budget, record.retained_bytes())?;
        sql(tx.execute(
            "INSERT INTO agent_ledger(domain,id,revision,payload) VALUES(?1,?2,?3,?4)",
            params![
                record.domain().as_slice(),
                record.id(),
                record.revision() as i64,
                record.container()
            ],
        ))?;
        boundary("agent-ledger-before-commit");
        tx.commit().map_err(|_| Error::CommitUnknown)?;
        boundary("agent-ledger-after-commit");
        Ok(())
    }
}
