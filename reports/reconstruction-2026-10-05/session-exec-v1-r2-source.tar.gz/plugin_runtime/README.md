# 可替换 Wasm 执行后端原型

当前C10检查点（2026-10-05）：本次开发分支更新收录C08–C10。C10已新增独立 `fs-directory-request-v1`、严格单import、包feature及只读discovery，复用原已批准selection和owner，不导出路径、句柄或新授权。Windows新Rust34（codec12/helper4/profile9/owner9）、既有回归191及frame5分别通过；Python33和两个原生C/C++消费者另计。新Rust Wasm仅编译通过，真实新Rust guest、C/C++ Wasm、Workbench产品／GUI、受保护Session与其他平台仍未验收。旧Core IO FileList保持Unsupported，SDK26／G04仍OPEN，无新Release。 详见[接口与实测边界](../reports/reconstruction-2026-10-05/directory-request-sdk.md)。

当前开发入口见 [项目状态](../docs/PROJECT_STATUS.md)、[SDK兼容](../docs/PLUGIN_SDK_COMPATIBILITY.md)和[IO作业](../docs/PLUGIN_IO_JOBS.md)。C07 Windows原IoWorker目录命令已限定通过，公开Core FileList仍Unsupported；C08已新增原worker秘密factory，当前复验为 `PASS（Windows限定）`。下文test.x计数和lint结果按其历史阶段阅读；C07封存的整库Clippy为exit101／10既有诊断／owned0；C08当时三文件fmt和strict库Rustc通过，整库Clippy仍exit101／10既有诊断／owned0（仅library lint范围），不能沿用早期“Clippy通过”作为当前资格。

历史原型起于 0.1.9-test.10（当时消息协议 v6）。当前 SDK／宿主使用运行协议 v7，支持 legacy guest ABI v1 和任务 ABI v2；[Windows SDK 候选](../reports/codex-morrow-v1.1/windows-sdk-013-2026-10-01.md)分别说明兼容与实验范围。早期Windows原型运行了实际C／C++／Rust Wasm，并通过可信适配器接入HostRuntime与SQLite；当轮版本和数据库边界按原报告保留。当前完整SDK资格与发行状态以项目状态为准。

## 原owner目录秘密factory（C08）

Windows `packages`下新增可信宿主 `capture_directory_fresh(File, CaptureLimits)`，返回原目录session／command handle。原owner经prepare及精确Manager／HostRuntime／ManagedInstance／IoBinding校验后生成OS熵；锁定 `getrandom 0.4.3`已在原依赖图中，只增加原生Windows使用边。原clock采样与对应FileList验证仍在同一短step；随机调用、hash、native查询和真实drop在clock／Control／Ticket锁外。生成前后原授权、取消与期限复验，没有生产可选entropy provider或secret读取接口。

熵错／部分填充／全零关闭，成功只产生目录观察；取消后原Unknown不自动重放。key所有权用Zeroizing保留并Drop清理，不能据此声称SHA／OS／编译器全部副本擦除。legacy显式seed接口及caller-copy责任保持；bare File没有picker或祖先来源。本轮fresh Windows Release／locked／offline实际factory14通过（69未选方法保留过滤），原owner115／九组、原件42／五组、网络100／十一组各自重新通过，不沿用或累计C07历史计数。42保留region14与reader1过滤，helper不另计方法。详情见 [C08说明](../reports/reconstruction-2026-10-05/directory-secret-factory.md)。SDK327／冻结57不重建，完整SDK26／G04仍OPEN，公开目录guest import未新增。

## 原owner相对目录选择（C09）

C09已完成限定Windows Release／locked／offline资格，见 [C09阶段说明](../reports/reconstruction-2026-10-05/directory-selection-owner.md)。可信宿主 `capture_directory_under(anchor, relative, limits)`只保留并核验原opened anchor到relative leaf的raw UTF-16句柄链，复用原worker FileList、原时钟、取消和预算；root加N个分量共享原8资源，32段语法上限不是可用深度。新selection_path8＋directory_selection12、C08 factory14、原owner九组115和原件42分别当前实际PASS；原件42为base9／dependency3／region7／reader主9／shared14，reader raw10含child helper1不加方法，region保留84过滤。17个credited测试进程合191 meaningful方法（raw192含child1），zero-match失败进程保留且不计功；这些数字不能作为SDK冻结。Workbench第二次Release x86_64 `--locked --offline --lib` check通过，首次缺offline asn1-rs0.7.2的exit101保留；只是编译检查，ProtectedSession／GUI／picker以上provenance和non-Windows产品执行NOT_RUN。C09 network100和Clippy明确NOT_RUN，不继承C08历史通过或lint结果。这不证明picker时刻、anchor以上来源或传入anchor的sharing策略，不增加guest FileList、目录guest或公共UI，blob耐久后端仍缺。SDK26／G04仍OPEN，公开FileList及conditional Replace仍Unsupported。C08/C09历史报告保留当时状态；本次开发分支更新收录C08–C10，无新Release。

## 执行与权限边界

插件编译为独立 wasm32-unknown-unknown 模块，导出 memory 和 morrow_run() -> i32。入口无参数：ABI v1 使用固定输入回归，ABI v2 从固定任务导入读取动态输入并交付有界结果。原生队列、实例池和有界资源恢复接口已有后续实现；完整长期持久调度及平台产品资格仍开放。模块不含 start 段，准备阶段不执行插件代码。

ABI v1 唯一允许的导入为 morrow_v1.exchange(input_offset, input_length, output_offset, output_capacity) -> i32。四个参数均为 Wasm i32；成功返回正响应长度，传输失败返回 -1，边界违规直接终止执行。输出容量必须为 65536 字节，输入为 1–65536 字节，两个区域必须有效且不重叠。正长度只代表收到协议消息，权限拒绝与提交结果须由 SDK 解码判断。

后端先验证完整输出空间，再复制输入，之后调用宿主；写回时重新取得线性内存视图。guest 不能指定宿主路径、连接、实例、权限或时钟。可信调用方通过闭包绑定实际连接，核心仍执行逐次授权。默认运行库只依赖执行器和 Wasm 解析器；原生可选 packages feature 增加核心适配，绑定包摘要、能力上限和连接。低层 Runner 的核心依赖仍仅用于测试。后端不拥有数据库或授权配置。

Runner 可复用已校验模块，每次 run 创建独立 Store，结束后释放该次线性内存。Runner每次Wasm Store仍独立；上层已有有界服务与依赖图，但不因此提供公共共享内存租约或长期实例持久调度。取消标志只影响执行／响应交付，不能代替核心撤权，也不能删除已提交内容。

## 基础exchange的可复现实验限额

| 项目 | 默认值／固定上限 |
| --- | --- |
| Wasm 文件 | 至多 4 MiB，二进制解析与验证，不加载预编译宿主机器码 |
| 指令 fuel | 每次 2000 万；调用方可设 1–1 亿 |
| 线性内存 | 默认 16 MiB；允许 64 KiB–64 MiB；至多一份内存 |
| 表 | 至多一张，最多 4096 元素 |
| 实例 | 每个 Store 至多一个 |
| 宿主调用 | 默认至多 16 次；可信调用方可设 0–1024 |
| 消息 | 64 KiB，必须在提交前通过输出范围检查 |

静态模块检查使用 EnforcedLimits::strict；以上是原型参数，不是性能结论或发行参数。缺省关闭 Wasmi 的 WAT 文本解析，仅测试依赖解析 WAT；不提供 WASI、直接操作系统文件／网络或自定义身份导入。实验性 `morrow_io_v1.call` 仅由专用 Runner 开放；受管固定文件字节读取的真实授权、预算和单帧限制见 [IO 整合验收](../reports/track-a-integration-2026-09-16.md)，不代表正式 guest 网络已接通。由内存增长限额触发的拒绝配置为 trap。

Wasmi 1.1.0 的 fuel 和 StoreLimits 用于验证可替换解释后端，锁定版本不代表它是最新版本或全平台最终选型。依据见 [固定版本 API](https://docs.rs/wasmi/1.1.0/wasmi/)、[资源限额](https://docs.rs/wasmi/1.1.0/wasmi/struct.StoreLimitsBuilder.html)。Wasmtime／Pulley、浏览器 Worker 与平台分发限制继续分别验证。

**取消不等于回滚。** 取消在进入执行、每次宿主调用前后及退出时检查。纯计算死循环由有限 fuel 终止，取消标志不保证立即打断它。fuel 不能终止正在阻塞的宿主数据库／系统调用，也不覆盖编译阶段耗时；已增加原生有界线程队列及期限，见 [后台任务](../docs/PLUGIN_TASKS.md)。生产执行器仍需多实例调度、进程／浏览器 Worker 终止与撤权协调。可信闭包必须遵守有界响应、禁止重入及禁止 panic 的约定。解释器隔离测试不等于对所有恶意模块、宿主依赖或六平台的完整安全验收。

无论 guest 返回错误码、trap、fuel 耗尽或取消，宿主调用都可能已经提交，必须查询固定操作 ID 的权威结果。guest 返回的 20 等示例状态值不构成提交证明；验收还独立重开 SQLite 检查操作回执和内容／事件关联。

## 历史原型验证

```powershell
pwsh -File tool/prepare_plugin_c_wasm.ps1
pwsh -File tool/verify_plugin_runtime.ps1
```

需要 Rust、Cap’n Proto 编译器、Python 3、PowerShell 7、LLVM 22 Clang 及 wasm32-unknown-unknown 目标；C/C++ 标准库由准备脚本获取。实际插件来自 [Rust 示例](../sdk/examples/rust-rename/src/lib.rs)、[C 示例](../sdk/examples/c-rename/plugin.c) 和 [C++ 示例](../sdk/examples/cpp-rename/plugin.cpp)，都使用类型化 SDK。每次请求还与核心独立编码的消息逐字节对照。

本轮通过：

- 格式检查、Clippy -D warnings；运行库启用 packages 共 37 项测试，SDK 15 项回归测试。
- 无效模块／导入／入口、禁止 start、初始内存超限、运行期内存增长／越界、死循环、宿主调用洪泛、缓冲区预检、取消和无效回复。
- 实际 C／C++／Rust SDK Wasm 模块：无权限拒绝、授权提交、重复请求、跨连接拒绝、撤权与停止后拒绝，以及取消后的结果核对。
- 三类首次提交后故障：取消、trap、fuel 耗尽；重开库均保留修订 2 和两条原子事件（初始创建与本次修改）。

- C++ 字符串／向量与 Rust 编解码共同分配期间保留数据、calloc 清零、realloc 保留数据及 256 字节对齐分配通过。
- C++ 访问无效回复与 128 MiB 分配失败均为 guest 内 trap、零宿主提交；OOM 样例将存储传给独立编译函数，避免被编译器消除分配。

产物和 SHA-256 见 [三语言运行记录](../reports/plugin-sdk-wasm-three-languages.md)。日志：build/plugin-runtime/verification.log；最终去除调试符号的模块已重新执行同一链路与错误路径。编译工具链或源码变化后应重新生成摘要。

当前只证明 Windows 上该解释后端与三语言示例的执行结果。已增加原生实验包校验、不可变安装与绑定执行，见 [插件包说明](../docs/PLUGIN_PACKAGE.md)。Manager启用状态与批准依赖锁、有限服务、UI1及实例池已有各自后续接口；签名产品资格、长期持久调度、公共mmap、完整第三方UI与各平台验收仍开放。后续guest/transport兼容候选已有各自冻结原件；完整SDK尚未冻结，项目发行状态以项目状态页为准。

原生 Worker 已通过四个实际包的后台任务／排空执行，并覆盖队列满、取消隔离、排空期限、旧连接拒绝和宿主线程故障。结果见 [验证记录](../reports/plugin-worker-validation.md)。版本化任务输入已接通，Flutter 主界面接入尚未完成。

后续已增加 guest ABI v2 动态任务导入和有界完成结果，三语言各 8 项宿主输入任务通过，见 [任务契约](../docs/PLUGIN_TASK_PROTOCOL.md)。新 profile 使用 `run_task`／`submit_task`，旧 run 不接收任务字节；原有 ABI v1 示例继续回归。内容任务历史产物摘要见 [任务验证记录](../reports/plugin-task-contract-validation.md)，早期报告对应其记录的构建。

任务契约 v2 新增纯转换 profile：固定输入和输出类型、64 KiB 数据上限、零内容调用，结果仅为插件数据。三语言真实转换、32 项 packages 测试及本次重建摘要见 [纯转换验证](../reports/plugin-transform-validation.md)。旧 task schema 包需重建；guest ABI v2 承载接口和主 Flutter 存储不变。

后续单包处理器注册及其验证见 [处理器验证](../reports/plugin-handler-validation.md)。纯转换任务在 guest 执行前匹配包内处理器、类型与输入长度；输出超过声明上限也不交付。当前共 37 项 packages 测试，包含执行前零指令拒绝和执行后输出拦截。

任务契约 v3 增加 TaskReport.failure。业务失败完整执行时 execution=Ok(0)，只有 failure 有值；trap／取消／协议失败时三种结果均为空。内容任务不能以插件错误替代核心回复。三语言实际路径见 [错误验证](../reports/plugin-failure-validation.md)。

## 三语言 UI 增量

已提供有界节点构造、事件读取与真实 UI 任务示例，见 [UI SDK 与接入边界](../docs/PLUGIN_UI_SDK.md)。C++ Wasm 入口显式初始化构造器，保留局部析构，不执行 WASI 命令退出清理或全局析构／atexit；每次任务的实例内存由宿主回收。主应用 UI 扩展点、在线会话、持久草稿与核心提交仍待接通。


## test.24 在线 UI 会话增量

`ui_session::UiSession` 将固定包、连接、视图与 core UI Session 接入真实后台任务；单事件背压、接纳失败回执与迟到结果丢弃已验证。Rust／C／C++ Wasm 各完成连续 27 个有效快照，见 [验证记录](../reports/plugin-ui-online-session-validation.md)。主应用的包 UI 注册、Flutter 控件在线接入、共享调度与内容保存仍待完成。

## test.30 主动依赖调用

新增独立 `dependency-calls-v1` 特性与固定Cap’n Proto契约。SDK在Rust、C和C++提供请求构造、完整原请求帧关联校验和Wasm导入适配；Runtime通过Manager当前批准锁路由，不接受guest自选提供者或授权。调用者最终结果可进入保留所有依赖撤权状态的EditProposal，内容提交仍由核心授权。当前仅单层纯转换，默认8次、可信策略硬上限16次。边界与用法见 [设计说明](../docs/PLUGIN_DYNAMIC_DEPENDENCIES.md)；实际验证与尚未完成项见 [test.30记录](../reports/test.30-dynamic-dependencies.md)。

## test.31 多层依赖图

新增可信run_graph入口：默认边深度4／全图16次，硬上限8／64；局部任务额度独立保留。拒绝活动包重入，允许顺序分支复用。根结果保存全部真实边和节点取消信号，提交时完整检查。原run仍为单层。见 [设计与边界](../docs/PLUGIN_DEPENDENCY_GRAPH.md) 和 [验证记录](../reports/test.31-dependency-graph.md)。

## test.32 自动准备与共享实例

新增只读ActivationPlan及绑定实际Host／Manager的实例池。独立root会话共享非根提供者，按真实失效传播必需关系；恢复须明确调用且有次数／间隔上限，不重试业务或恢复旧对象grant。见 [设计与边界](../docs/PLUGIN_INSTANCE_POOL.md) 及 [验证记录](../reports/test.32-instance-pool.md)。

## test.33 普通任务池接入

Pool新增普通Task监督与按根撤销对象授权；默认Windows工作台使用池会话，实际执行故障后停止根并保持已有内容可读。没有放宽依赖导入或自动任务重试，详细边界见 [实例池设计](../docs/PLUGIN_INSTANCE_POOL.md) 与 [工作台接入记录](../reports/test.33-workbench-pool.md)。

## test.34 纯转换捕获与重放

Pool.record_transform实际执行并保留自包含PB＋LZ4历史证据；morrow-transform-replay独立工具只在无生产宿主的Runner中比较原始观察。旧包与注册表不再存在时仍可复现，不恢复旧授权，不代表签名审计或内容提交。详见 [设计](../docs/PLUGIN_TASK_EVIDENCE.md)。
