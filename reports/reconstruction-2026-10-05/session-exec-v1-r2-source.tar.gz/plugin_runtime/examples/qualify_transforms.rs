//! Real pure computation in C/C++/Rust Wasm; no content grants or content calls.
use morrow_core::{
    content::CardRecord,
    dispatch::HostRuntime,
    plugin_package::catalog,
    store::{EventBudget, Store},
    task::{Invocation, MAX_VALUE_BYTES, Transform},
};
use morrow_plugin_runtime::{
    Limits,
    package::PreparedPackage,
    worker::{Phase, Worker},
};
use std::time::{Duration, Instant};
fn main() -> Result<(), Box<dyn std::error::Error>> {
    let paths: Vec<_> = std::env::args().skip(1).collect();
    if paths.is_empty() {
        return Err("transform package paths required".into());
    }
    for path in paths {
        let p = PreparedPackage::new(
            catalog::read_file(std::path::Path::new(&path))?,
            Limits::default(),
        )
        .unwrap();
        assert!(p.package().capabilities().is_empty());
        let dir = tempfile::tempdir()?;
        let db = dir.path().join("db");
        let mut store = Store::open(&db, EventBudget::default())?;
        store.create_local(
            "seed",
            &CardRecord::new("card", "note", 1, "untouched", vec![])?,
        )?;
        let mut host = HostRuntime::new(store)?;
        let c = p.connect(&mut host)?;
        assert_eq!(p.package().manifest().transform_handlers.len(), 3);
        for (handler, input_type, output_type) in [
            ("missing", "bytes", "bytes"),
            ("bytes.reverse", "other", "bytes"),
            ("bytes.reverse", "bytes", "other"),
        ] {
            let bad = Invocation::new_transform(
                "invalid",
                Transform {
                    handler: handler.into(),
                    input_type: input_type.into(),
                    output_type: output_type.into(),
                    input: vec![1],
                },
            )?;
            let result = p.run_task(
                &mut host,
                &c,
                &bad,
                || panic!("invalid task entered core"),
                Default::default(),
            );
            assert_eq!(
                result.execution.outcome,
                Err(morrow_plugin_runtime::Fault::TaskProtocol)
            );
            assert_eq!(result.execution.fuel_remaining, p.limits().fuel);
            assert_eq!(result.execution.host_calls, 0);
            assert!(result.output.is_none() && result.response.is_none());
        }
        let mut worker = Worker::spawn(
            p,
            host,
            c,
            || panic!("pure transform attempted host clock"),
            16,
        )
        .unwrap();
        let timeout = Duration::from_secs(30);
        let until = Instant::now() + timeout;
        let mut tasks = vec![];
        let samples = [
            vec![],
            b"Ascii 123".to_vec(),
            "Hello 世界🌈".as_bytes().to_vec(),
            (0..=255).collect::<Vec<u8>>(),
            (0..MAX_VALUE_BYTES).map(|n| (n % 256) as u8).collect(),
        ];
        for handler in [
            "bytes.reverse",
            "bytes.ascii-uppercase",
            "bytes.require-ascii",
        ] {
            for input in &samples {
                let mut expected = input.clone();
                if handler == "bytes.reverse" {
                    expected.reverse();
                } else if handler == "bytes.ascii-uppercase" {
                    expected.make_ascii_uppercase();
                }
                let invocation = Invocation::new_transform(
                    &format!("pure-{}", tasks.len()),
                    Transform {
                        handler: handler.into(),
                        input_type: "bytes".into(),
                        output_type: "bytes".into(),
                        input: input.clone(),
                    },
                )?;
                tasks.push((
                    worker.submit_task(invocation, timeout).unwrap(),
                    expected,
                    handler == "bytes.require-ascii" && !input.is_ascii(),
                ));
            }
        }
        worker.drain(timeout).unwrap();
        for (task, expected, should_fail) in &mut tasks {
            let result = loop {
                if let Some(r) = task.try_result().unwrap() {
                    break r;
                }
                assert!(Instant::now() < until);
                std::thread::sleep(Duration::from_millis(1));
            };
            assert_eq!(result.execution.outcome, Ok(0));
            assert_eq!(result.execution.host_calls, 0);
            assert!(result.response.is_none());
            if *should_fail {
                assert!(result.output.is_none());
                let failure = result.failure.expect("correlated plugin failure");
                assert_eq!(
                    failure.code,
                    morrow_core::task::FailureCode::UnsupportedInput
                );
                assert_eq!(failure.message, "Input contains non-ASCII bytes");
                continue;
            }
            assert!(result.failure.is_none());
            let output = result.output.expect("correlated produced data");
            assert_eq!(output.type_id, "bytes");
            assert_eq!(&output.bytes, expected);
        }
        let host = loop {
            if let Some(h) = worker.try_finish().unwrap() {
                break h;
            }
            assert!(Instant::now() < until);
            std::thread::sleep(Duration::from_millis(1));
        };
        assert_eq!(worker.phase(), Phase::Stopped);
        assert_eq!(host.store_local().pending(0, 10)?.len(), 1);
        host.store_local().integrity_check()?;
        drop(host);
        let store = Store::open_existing(&db, EventBudget::default())?;
        assert_eq!(store.card("card")?.unwrap().summary().title, "untouched");
        store.integrity_check()?;
        println!(
            "PASS: {path}: 3 registration rejections before guest; 15 pure tasks (12 outputs, 3 structured failures), empty/Unicode bytes/all byte values/64KiB; independently verified output, zero core calls, no content or event changes"
        );
    }
    Ok(())
}
