//! Optional trusted adapter. The module and connection must refer to the same archive.
use crate::{Cancellation, Fault, Limits, Report, Runner};
use morrow_core::{
    dispatch::{Connection, HostRuntime},
    plugin_package::Package,
};
#[cfg(not(target_arch = "wasm32"))]
mod frame;
pub struct PreparedPackage {
    package: Package,
    runner: Runner,
    limits: Limits,
}
impl PreparedPackage {
    pub fn new(package: Package, host_limits: Limits) -> Result<Self, Fault> {
        // Validate host policy before intersecting; an invalid policy must not silently pass.
        if host_limits.fuel == 0
            || host_limits.fuel > 100_000_000
            || host_limits.memory_bytes < 65536
            || host_limits.memory_bytes > 64 * 1024 * 1024
            || host_limits.host_calls > 1024
        {
            return Err(Fault::Limits);
        }
        let budget = package
            .manifest()
            .budget
            .as_ref()
            .expect("validated package budget");
        let limits = Limits {
            fuel: host_limits.fuel.min(budget.fuel),
            memory_bytes: host_limits.memory_bytes.min(budget.memory_bytes as usize),
            host_calls: host_limits.host_calls.min(budget.host_calls),
        };
        let dependency = package
            .manifest()
            .required_features
            .iter()
            .any(|f| f == morrow_core::plugin_package::DEPENDENCY_CALLS_FEATURE);
        let directory = package.manifest().required_features.iter()
            .any(|feature| feature == morrow_core::plugin_package::DIRECTORY_REQUEST_FEATURE);
        let runner = if directory {
            if dependency || package.io_declaration().is_none()
                || package.channel_declaration().is_some() || package.mutation_enabled() {
                return Err(Fault::UnsupportedAbi);
            }
            Runner::new_directory_task(package.module(), limits)?
        } else if package.channel_declaration().is_some() {
            if dependency
                || package.io_declaration().is_some()
                || package.mutation_enabled()
                || morrow_core::channel::MAX_WIRE_BYTES != crate::MAX_TASK_BYTES
                || !package
                    .manifest()
                    .required_features
                    .iter()
                    .any(|f| f == morrow_core::channel::FEATURE)
            {
                return Err(Fault::UnsupportedAbi);
            }
            Runner::new_channel_task(package.module(), limits)?
        } else if package.mutation_enabled() {
            if dependency
                || package.io_declaration().is_none()
                || morrow_core::mutation::MAX_FRAME_BYTES != crate::MAX_MUTATION_FRAME_BYTES
            {
                return Err(Fault::UnsupportedAbi);
            }
            Runner::new_mutation_task(package.module(), limits)?
        } else if package.io_declaration().is_some() {
            if dependency {
                return Err(Fault::UnsupportedAbi);
            }
            Runner::new_io_task(package.module(), limits)?
        } else if dependency {
            Runner::new_dependency_task(package.module(), limits)?
        } else if package.manifest().guest_abi_version == 2 {
            Runner::new_task(package.module(), limits)?
        } else {
            Runner::new(package.module(), limits)?
        };
        Ok(Self {
            package,
            runner,
            limits,
        })
    }
    /// Internal fixed-resource adapter only; raw callbacks are not managed authority.
    #[cfg(not(target_arch = "wasm32"))]
    pub(crate) fn run_file_frame<'a>(
        &self,
        input: &'a [u8],
        io: crate::Exchange<'a>,
        cancel: Cancellation,
    ) -> crate::TaskRun {
        self.run_io_frame(input, io, cancel)
    }
    /// Deny content imports; the managed adapter validates response binding.
    #[cfg(not(target_arch = "wasm32"))]
    pub(crate) fn run_io_frame<'a>(
        &self,
        input: &'a [u8],
        io: crate::Exchange<'a>,
        cancel: Cancellation,
    ) -> crate::TaskRun {
        let mut frame = match self.start_io_frame(input, cancel) {
            Ok(frame) => frame,
            Err(run) => return run,
        };
        while let Some(call) = frame.pending() {
            let token = call.token.clone();
            let response = io(&call.bytes);
            frame.resume(&token, response).expect("same pending call");
        }
        frame.finish()
    }
    #[cfg(all(feature = "packages", not(target_arch = "wasm32")))]
    pub(crate) fn start_channel(
        &self,
        input: &[u8],
        cancel: Cancellation,
    ) -> Result<crate::continuation::Execution, Fault> {
        if !self.runner.channel_abi || self.package.channel_declaration().is_none() {
            return Err(Fault::UnsupportedAbi);
        }
        crate::continuation::Execution::start(&self.runner, Some(input), cancel)
    }
    pub fn package(&self) -> &Package {
        &self.package
    }
    pub fn limits(&self) -> Limits {
        self.limits
    }
    /// No grants are created here. This is called only after host approval, not by the guest.
    pub fn connect(&self, host: &mut HostRuntime) -> morrow_core::Result<Connection> {
        host.connect_package(&self.package)
    }
    /// Bind a previously approved ceiling to a fresh instance; individual grants remain separate.
    pub fn connect_approved(
        &self,
        host: &mut HostRuntime,
        approved: &std::collections::BTreeSet<morrow_core::lifecycle::GrantKind>,
    ) -> morrow_core::Result<Connection> {
        host.connect_package_approved(&self.package, approved)
    }
    /// Clock belongs to the trusted host. No guest-selected identity or callback is accepted.
    pub fn run(
        &self,
        host: &mut HostRuntime,
        connection: &Connection,
        mut clock: impl FnMut() -> u64,
        cancel: Cancellation,
    ) -> Report {
        if self.package.io_declaration().is_some() || self.package.channel_declaration().is_some() {
            return Report {
                outcome: Err(Fault::UnsupportedAbi),
                host_calls: 0,
                fuel_remaining: self.limits.fuel,
            };
        }
        if connection.package_digest() != Some(self.package.digest()) {
            return Report {
                outcome: Err(Fault::PackageBinding),
                host_calls: 0,
                fuel_remaining: self.limits.fuel,
            };
        }
        if host.connection_phase(connection) != Ok(morrow_core::lifecycle::InstancePhase::Ready) {
            return Report {
                outcome: Err(Fault::InactiveConnection),
                host_calls: 0,
                fuel_remaining: self.limits.fuel,
            };
        }
        self.runner.run(
            &mut |input| host.dispatch(connection, input, &mut clock).map_err(|_| ()),
            cancel,
        )
    }
}

#[derive(Debug)]
pub struct TaskReport {
    pub execution: Report,
    pub response: Option<morrow_core::response::Response>,
    pub output: Option<morrow_core::task::TransformOutput>,
    pub failure: Option<morrow_core::task::PluginFailure>,
}
impl PreparedPackage {
    pub fn run_task(
        &self,
        host: &mut HostRuntime,
        connection: &Connection,
        input: &morrow_core::task::Invocation,
        mut clock: impl FnMut() -> u64,
        cancel: Cancellation,
    ) -> TaskReport {
        let fault = if self.package.io_declaration().is_some()
            || self.package.channel_declaration().is_some()
        {
            Some(Fault::UnsupportedAbi)
        } else if connection.package_digest() != Some(self.package.digest()) {
            Some(Fault::PackageBinding)
        } else if host.connection_phase(connection)
            != Ok(morrow_core::lifecycle::InstancePhase::Ready)
        {
            Some(Fault::InactiveConnection)
        } else if self.package.manifest().guest_abi_version != 2 {
            Some(Fault::UnsupportedAbi)
        } else {
            None
        };
        let registration = input.transform().map(|t| self.package.transform_handler(t));
        let fault = fault.or(match &registration {
            Some(Err(_)) => Some(Fault::TaskProtocol),
            _ => None,
        });
        if let Some(fault) = fault {
            return TaskReport {
                execution: Report {
                    outcome: Err(fault),
                    host_calls: 0,
                    fuel_remaining: self.limits.fuel,
                },
                response: None,
                output: None,
                failure: None,
            };
        }
        let mut actual = None;
        let mut protocol_fault = false;
        let mut called = false;
        let run = self.runner.run_task(
            input.bytes(),
            &mut |command| {
                if input.transform().is_some()
                    || called
                    || protocol_fault
                    || command != input.command_bytes()
                {
                    protocol_fault = true;
                    return Err(());
                }
                called = true;
                let response = host
                    .dispatch(connection, command, &mut clock)
                    .map_err(|_| ())?;
                actual = Some(response.clone());
                Ok(response)
            },
            cancel,
        );
        let mut execution = run.report;
        let mut output = None;
        let mut failure = None;
        use morrow_core::task::TransformResult;
        let response = if execution.outcome.is_ok() && input.transform().is_some() {
            match run.completion {
                Some(completion) if !protocol_fault => match input
                    .verify_transform_result(&completion)
                {
                    Ok(TransformResult::Output(value))
                        if registration
                            .as_ref()
                            .and_then(|r| r.as_ref().ok())
                            .is_some_and(|h| value.bytes.len() <= h.max_output_bytes as usize) =>
                    {
                        output = Some(value)
                    }
                    Ok(TransformResult::Failure(value)) => failure = Some(value),
                    Ok(_) => execution.outcome = Err(Fault::TaskProtocol),
                    Err(_) => execution.outcome = Err(Fault::TaskProtocol),
                },
                _ => execution.outcome = Err(Fault::TaskProtocol),
            };
            None
        } else if execution.outcome.is_ok() {
            match (run.completion, actual) {
                (Some(completion), Some(actual)) if !protocol_fault => {
                    match input.verify_completion(&completion, &actual) {
                        Ok(v) => Some(v),
                        Err(_) => {
                            execution.outcome = Err(Fault::TaskProtocol);
                            None
                        }
                    }
                }
                _ => {
                    execution.outcome = Err(Fault::TaskProtocol);
                    None
                }
            }
        } else {
            None
        };
        TaskReport {
            execution,
            response,
            output,
            failure,
        }
    }
}

impl PreparedPackage {
    /// Only the managed router supplies this callback; ordinary content exchange is denied.
    pub(crate) fn run_dependency_transform(
        &self,
        input: &morrow_core::task::Invocation,
        dependency: crate::Exchange<'_>,
        cancel: Cancellation,
    ) -> TaskReport {
        let registration = input
            .transform()
            .and_then(|t| self.package.transform_handler(t).ok());
        let Some(registration) = registration else {
            return TaskReport {
                execution: Report {
                    outcome: Err(Fault::TaskProtocol),
                    host_calls: 0,
                    fuel_remaining: self.limits.fuel,
                },
                response: None,
                output: None,
                failure: None,
            };
        };
        let forbidden_exchange = std::cell::Cell::new(false);
        let run = self.runner.run_task_with_dependencies(
            input.bytes(),
            &mut |_| {
                forbidden_exchange.set(true);
                Err(())
            },
            &mut |bytes| {
                if forbidden_exchange.get() {
                    Err(())
                } else {
                    dependency(bytes)
                }
            },
            cancel,
        );
        let mut execution = run.report;
        // A guest cannot ignore a denied content exchange and manufacture a successful intent.
        if forbidden_exchange.get() && execution.outcome.is_ok() {
            execution.outcome = Err(Fault::TaskProtocol);
        }
        let mut output = None;
        let mut failure = None;
        if execution.outcome.is_ok() {
            match run
                .completion
                .and_then(|c| input.verify_transform_result(&c).ok())
            {
                Some(morrow_core::task::TransformResult::Output(value))
                    if value.bytes.len() <= registration.max_output_bytes as usize =>
                {
                    output = Some(value)
                }
                Some(morrow_core::task::TransformResult::Failure(value)) => failure = Some(value),
                _ => execution.outcome = Err(Fault::TaskProtocol),
            }
        }
        TaskReport {
            execution,
            output,
            failure,
            response: None,
        }
    }
}
