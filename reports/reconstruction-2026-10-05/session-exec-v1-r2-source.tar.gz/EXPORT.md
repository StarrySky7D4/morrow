# Reviewed session/safe-exec-basic R2 source bundle

Keep this directory layout: the independent R2 crate references ../../core.
README.md and LICENSE retain repository documentation and licensing. This is
source and recorded evidence, without a dependency cache, production transport,
OS execution-domain qualification, or a full SDK26 freeze.

Verify with an independently reviewed raw manifest SHA256, never a value chosen
by this bundle itself:

    python3 tool/verify_session_exec_r2.py verify --root . --baseline session-exec-r2-manifest.json --expected-pin REVIEWED_SHA256 --recorded-executables-only --json

The recorded-executables-only switch checks historical input digests without
requiring the original machine's executable paths. It performs no compilation
and never authenticates a reviewer or recorded execution.

For a separate client crate, use this dependency (relative to its Cargo.toml):

    morrow-agent-session-exec-v1-r2 = { path = "../source/extensions/agent-session-exec-v1-r2", default-features = false }

Then run cargo check --locked --offline --manifest-path Cargo.toml --target-dir
an-explicit-build-directory using prepared pinned dependencies. A Cargo.lock
must already exist. Host adapters are separate declared source roots; enable
and validate their reviewed feature selection separately. No build outputs are
source inputs, and there is no fallback to an upstream execution backend.
